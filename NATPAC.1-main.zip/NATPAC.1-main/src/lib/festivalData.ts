export interface Festival {
  name: string;
  date: string;
  month: string;
  description: string;
  location: string;
  state: string;
  district?: string;
}

export interface TouristPlace {
  name: string;
  description: string;
  location: string;
  state: string;
  district?: string;
  type: string;
}

// Major festivals in India
export const majorFestivals: Festival[] = [
  {
    name: "Diwali",
    date: "November 12, 2024",
    month: "November",
    description: "Festival of Lights celebrated across India",
    location: "Pan-India",
    state: "All States"
  },
  {
    name: "Holi",
    date: "March 25, 2024",
    month: "March", 
    description: "Festival of Colors marking spring arrival",
    location: "Pan-India",
    state: "All States"
  },
  {
    name: "Durga Puja",
    date: "October 15-19, 2024",
    month: "October",
    description: "Major festival celebrating Goddess Durga",
    location: "Kolkata, West Bengal",
    state: "West Bengal"
  },
  {
    name: "Ganesh Chaturthi",
    date: "September 7, 2024",
    month: "September",
    description: "Celebration of Lord Ganesha",
    location: "Mumbai, Maharashtra",
    state: "Maharashtra"
  },
  {
    name: "Onam",
    date: "September 15, 2024",
    month: "September",
    description: "Harvest festival of Kerala",
    location: "Kochi, Kerala",
    state: "Kerala"
  },
  {
    name: "Navratri",
    date: "October 3-11, 2024",
    month: "October",
    description: "Nine nights of dance and devotion",
    location: "Ahmedabad, Gujarat",
    state: "Gujarat"
  },
  {
    name: "Kumbh Mela",
    date: "January-March 2025",
    month: "January-March",
    description: "World's largest religious gathering",
    location: "Prayagraj, Uttar Pradesh",
    state: "Uttar Pradesh"
  },
  {
    name: "Pushkar Fair",
    date: "November 15-23, 2024",
    month: "November",
    description: "Famous camel fair and festival",
    location: "Pushkar, Rajasthan",
    state: "Rajasthan"
  }
];

// District-wise festivals
export const districtFestivals: { [district: string]: Festival[] } = {
  "Mumbai": [
    {
      name: "Ganesh Chaturthi",
      date: "September 7, 2024",
      month: "September",
      description: "Grand celebration with elaborate pandals",
      location: "Mumbai",
      state: "Maharashtra",
      district: "Mumbai"
    },
    {
      name: "Navratri",
      date: "October 3-11, 2024", 
      month: "October",
      description: "Nine nights of Garba and Dandiya",
      location: "Mumbai",
      state: "Maharashtra",
      district: "Mumbai"
    }
  ],
  "Delhi": [
    {
      name: "Dussehra",
      date: "October 24, 2024",
      month: "October",
      description: "Victory of good over evil celebration",
      location: "Delhi",
      state: "Delhi",
      district: "Delhi"
    },
    {
      name: "Karva Chauth",
      date: "November 1, 2024",
      month: "November", 
      description: "Festival celebrated by married women",
      location: "Delhi",
      state: "Delhi",
      district: "Delhi"
    }
  ],
  "Kolkata": [
    {
      name: "Durga Puja",
      date: "October 15-19, 2024",
      month: "October",
      description: "Grandest festival of Bengal",
      location: "Kolkata",
      state: "West Bengal",
      district: "Kolkata"
    },
    {
      name: "Kali Puja",
      date: "November 12, 2024",
      month: "November",
      description: "Worship of Goddess Kali",
      location: "Kolkata", 
      state: "West Bengal",
      district: "Kolkata"
    }
  ],
  "Bangalore": [
    {
      name: "Karaga",
      date: "April 18, 2024",
      month: "April",
      description: "Traditional festival of Bangalore",
      location: "Bangalore",
      state: "Karnataka",
      district: "Bangalore"
    },
    {
      name: "Dasara",
      date: "October 24, 2024",
      month: "October",
      description: "Royal celebration in Mysore style",
      location: "Bangalore",
      state: "Karnataka", 
      district: "Bangalore"
    }
  ],
  "Chennai": [
    {
      name: "Thai Pusam",
      date: "January 25, 2024",
      month: "January",
      description: "Tamil festival honoring Lord Murugan",
      location: "Chennai",
      state: "Tamil Nadu",
      district: "Chennai"
    },
    {
      name: "Pongal",
      date: "January 15, 2024",
      month: "January",
      description: "Harvest festival of Tamil Nadu",
      location: "Chennai",
      state: "Tamil Nadu",
      district: "Chennai"
    }
  ]
};

// Top tourist places
export const topTouristPlaces: TouristPlace[] = [
  {
    name: "Taj Mahal",
    description: "Iconic symbol of love and Mughal architecture",
    location: "Agra, Uttar Pradesh",
    state: "Uttar Pradesh",
    type: "Monument"
  },
  {
    name: "Jaipur City Palace",
    description: "Royal palace complex showcasing Rajasthani architecture",
    location: "Jaipur, Rajasthan", 
    state: "Rajasthan",
    type: "Palace"
  },
  {
    name: "Kerala Backwaters",
    description: "Serene network of canals and lagoons",
    location: "Alleppey, Kerala",
    state: "Kerala",
    type: "Natural"
  },
  {
    name: "Goa Beaches",
    description: "Beautiful beaches with Portuguese heritage",
    location: "Goa",
    state: "Goa",
    type: "Beach"
  },
  {
    name: "Ladakh",
    description: "High-altitude desert with stunning landscapes",
    location: "Leh, Ladakh",
    state: "Ladakh",
    type: "Mountain"
  },
  {
    name: "Varanasi Ghats",
    description: "Sacred city on the banks of river Ganga",
    location: "Varanasi, Uttar Pradesh",
    state: "Uttar Pradesh",
    type: "Religious"
  },
  {
    name: "Hampi",
    description: "Ancient ruins of Vijayanagara Empire",
    location: "Hampi, Karnataka",
    state: "Karnataka", 
    type: "Heritage"
  },
  {
    name: "Valley of Flowers",
    description: "UNESCO World Heritage site with rare flowers",
    location: "Uttarakhand",
    state: "Uttarakhand",
    type: "Natural"
  }
];

// District-wise tourist places
export const districtTouristPlaces: { [district: string]: TouristPlace[] } = {
  "Mumbai": [
    {
      name: "Gateway of India",
      description: "Iconic arch monument overlooking Arabian Sea",
      location: "Mumbai",
      state: "Maharashtra",
      district: "Mumbai",
      type: "Monument"
    },
    {
      name: "Marine Drive",
      description: "Beautiful waterfront promenade",
      location: "Mumbai",
      state: "Maharashtra", 
      district: "Mumbai",
      type: "Waterfront"
    }
  ],
  "Delhi": [
    {
      name: "Red Fort",
      description: "Historic Mughal fort and UNESCO World Heritage site",
      location: "Delhi",
      state: "Delhi",
      district: "Delhi",
      type: "Fort"
    },
    {
      name: "India Gate",
      description: "War memorial and iconic landmark",
      location: "Delhi",
      state: "Delhi",
      district: "Delhi",
      type: "Monument"
    }
  ],
  "Jaipur": [
    {
      name: "Amber Fort",
      description: "Majestic fort with stunning architecture",
      location: "Jaipur",
      state: "Rajasthan",
      district: "Jaipur",
      type: "Fort"
    },
    {
      name: "Hawa Mahal",
      description: "Palace of Winds with unique facade",
      location: "Jaipur",
      state: "Rajasthan",
      district: "Jaipur", 
      type: "Palace"
    }
  ],
  "Agra": [
    {
      name: "Taj Mahal",
      description: "Symbol of eternal love",
      location: "Agra",
      state: "Uttar Pradesh",
      district: "Agra",
      type: "Monument"
    },
    {
      name: "Agra Fort",
      description: "Magnificent Mughal fortress",
      location: "Agra",
      state: "Uttar Pradesh",
      district: "Agra",
      type: "Fort"
    }
  ]
};

export const getDistrictOptions = (): string[] => {
  return Object.keys(districtFestivals).concat(Object.keys(districtTouristPlaces))
    .filter((value, index, self) => self.indexOf(value) === index)
    .sort();
};