import { Loader } from '@googlemaps/js-api-loader';

const GOOGLE_MAPS_API_KEY = 'AIzaSyB9HukUlzxEVkSsUMuqYEkx9uEufGrNo-8';

// Initialize Google Maps loader
export const googleMapsLoader = new Loader({
  apiKey: GOOGLE_MAPS_API_KEY,
  version: 'weekly',
  libraries: ['places', 'geometry'],
});

let googleMapsLoaded = false;
let google: any = null;

export const loadGoogleMaps = async () => {
  if (googleMapsLoaded && google) {
    return google;
  }

  try {
    google = await googleMapsLoader.load();
    googleMapsLoaded = true;
    return google;
  } catch (error) {
    console.error('Error loading Google Maps:', error);
    throw error;
  }
};

// Get current location
export const getCurrentLocation = (): Promise<GeolocationPosition> => {
  return new Promise((resolve, reject) => {
    if (!navigator.geolocation) {
      reject(new Error('Geolocation is not supported by this browser'));
      return;
    }

    navigator.geolocation.getCurrentPosition(
      (position) => resolve(position),
      (error) => reject(error),
      {
        enableHighAccuracy: true,
        timeout: 10000,
        maximumAge: 300000 // 5 minutes
      }
    );
  });
};

// Convert coordinates to address
export const geocodeLocation = async (lat: number, lng: number): Promise<string> => {
  const google = await loadGoogleMaps();
  const geocoder = new google.maps.Geocoder();

  return new Promise((resolve, reject) => {
    geocoder.geocode(
      { location: { lat, lng } },
      (results: any[], status: string) => {
        if (status === 'OK' && results[0]) {
          // Get the formatted address, preferring locality/city
          const addressComponents = results[0].address_components;
          const city = addressComponents.find((component: any) => 
            component.types.includes('locality') || 
            component.types.includes('administrative_area_level_2')
          );
          
          resolve(city ? city.long_name : results[0].formatted_address);
        } else {
          reject(new Error('Geocoding failed: ' + status));
        }
      }
    );
  });
};

// Validate place exists
export const validatePlace = async (placeName: string): Promise<{ valid: boolean; suggestions?: string[]; place?: any }> => {
  const google = await loadGoogleMaps();
  const service = new google.maps.places.PlacesService(document.createElement('div'));

  return new Promise((resolve) => {
    const request = {
      query: placeName,
      fields: ['name', 'geometry', 'formatted_address', 'place_id'],
    };

    service.textSearch(request, (results: any[], status: string) => {
      if (status === google.maps.places.PlacesServiceStatus.OK && results && results.length > 0) {
        // Check if any result is an exact or close match
        const exactMatch = results.find(place => 
          place.name.toLowerCase() === placeName.toLowerCase() ||
          place.formatted_address.toLowerCase().includes(placeName.toLowerCase())
        );

        if (exactMatch) {
          resolve({ 
            valid: true, 
            place: {
              name: exactMatch.name,
              address: exactMatch.formatted_address,
              placeId: exactMatch.place_id,
              location: {
                lat: exactMatch.geometry.location.lat(),
                lng: exactMatch.geometry.location.lng()
              }
            }
          });
        } else {
          // Provide suggestions
          const suggestions = results.slice(0, 3).map(place => place.formatted_address);
          resolve({ valid: false, suggestions });
        }
      } else {
        resolve({ valid: false, suggestions: [] });
      }
    });
  });
};

// Get distance and duration between two places
export const getRouteInfo = async (origin: string, destination: string, mode: string = 'DRIVING'): Promise<{
  distance: number;
  duration: number;
  status: string;
}> => {
  const google = await loadGoogleMaps();
  const service = new google.maps.DistanceMatrixService();

  // Map our modes to Google Maps travel modes
  const modeMapping: { [key: string]: any } = {
    'Walk': google.maps.TravelMode.WALKING,
    'Bike': google.maps.TravelMode.BICYCLING,
    'Bus': google.maps.TravelMode.TRANSIT,
    'Train': google.maps.TravelMode.TRANSIT,
    'Car': google.maps.TravelMode.DRIVING,
  };

  const travelMode = modeMapping[mode] || google.maps.TravelMode.DRIVING;

  return new Promise((resolve, reject) => {
    service.getDistanceMatrix(
      {
        origins: [origin],
        destinations: [destination],
        travelMode: travelMode,
        unitSystem: google.maps.UnitSystem.METRIC,
        avoidHighways: false,
        avoidTolls: false,
      },
      (response: any, status: string) => {
        if (status === 'OK') {
          const element = response.rows[0].elements[0];
          if (element.status === 'OK') {
            resolve({
              distance: Math.round(element.distance.value / 1000), // Convert to km
              duration: Math.round(element.duration.value / 60), // Convert to minutes
              status: 'OK'
            });
          } else {
            resolve({
              distance: 0,
              duration: 0,
              status: element.status
            });
          }
        } else {
          reject(new Error('Distance Matrix request failed: ' + status));
        }
      }
    );
  });
};

// Calculate cost based on mode and distance
export const calculateCost = (mode: string, distance: number): number => {
  const costPerKm: { [key: string]: number } = {
    'Walk': 0,
    'Bike': 2, // Maintenance/wear
    'Bus': 8,
    'Train': 5,
    'Car': 12, // Fuel + maintenance
  };

  const baseCost = costPerKm[mode] || 10;
  const cost = Math.max(baseCost * distance, mode === 'Walk' ? 0 : 10); // Minimum cost except for walking
  
  // Add some realistic variance
  const variance = Math.random() * 0.2 - 0.1; // ±10%
  return Math.round(cost * (1 + variance));
};

// Open Google Maps with directions
export const openInGoogleMaps = (origin: string, destination: string, mode: string = 'driving') => {
  // Validate that both origin and destination exist
  if (!origin || !destination) {
    throw new Error('Both origin and destination are required');
  }

  try {
    const modeParam = mode.toLowerCase() === 'walk' || mode.toLowerCase() === 'walking' ? 'walking' : 
                     mode.toLowerCase() === 'bike' || mode.toLowerCase() === 'bicycle' ? 'bicycling' :
                     mode.toLowerCase() === 'bus' || mode.toLowerCase() === 'train' ? 'transit' : 'driving';
    
    const url = `https://www.google.com/maps/dir/?api=1&origin=${encodeURIComponent(origin)}&destination=${encodeURIComponent(destination)}&travelmode=${modeParam}`;
    
    // Open in new tab/window
    const newWindow = window.open(url, '_blank', 'noopener,noreferrer');
    
    if (!newWindow) {
      // If popup is blocked, show user-friendly message
      alert('Please allow popups for this site to open Google Maps, or copy this URL: ' + url);
    }
    
    return Promise.resolve(true);
  } catch (error) {
    console.error('Error opening Google Maps:', error);
    alert('Unable to open Google Maps. Please check your internet connection and try again.');
    return Promise.resolve(false);
  }
};

// Get autocomplete suggestions
export const getPlaceSuggestions = async (input: string): Promise<string[]> => {
  if (!input || input.length < 2) return [];

  const google = await loadGoogleMaps();
  const service = new google.maps.places.AutocompleteService();

  return new Promise((resolve) => {
    service.getPlacePredictions(
      {
        input: input,
        componentRestrictions: { country: 'IN' }, // Restrict to India
        types: ['(cities)'], // Focus on cities
      },
      (predictions: any[], status: string) => {
        if (status === google.maps.places.PlacesServiceStatus.OK && predictions) {
          const suggestions = predictions.slice(0, 5).map(prediction => prediction.description);
          resolve(suggestions);
        } else {
          resolve([]);
        }
      }
    );
  });
};