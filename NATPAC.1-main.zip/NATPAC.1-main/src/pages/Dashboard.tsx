import { useState, useEffect } from 'react';
import { useAuth } from '@/contexts/AuthContext';
import { useTrip } from '@/contexts/TripContext';
import Layout from '@/components/Layout';
import TripPlanner from '@/components/TripPlanner';
import RouteResults from '@/components/RouteResults';
import TripDetails from '@/components/TripDetails';
import IncompleteTripBanner from '@/components/IncompleteTripBanner';

const Dashboard = () => {
  const { user } = useAuth();
  const { incompleteTrip } = useTrip();
  const [searchResults, setSearchResults] = useState<any[]>([]);
  const [showResults, setShowResults] = useState(false);
  const [showTripDetails, setShowTripDetails] = useState(false);
  const [selectedRoute, setSelectedRoute] = useState<any>(null);
  const [searchQuery, setSearchQuery] = useState({ origin: '', destination: '' });

  // Listen for resume incomplete trip events
  useEffect(() => {
    const handleResumeTrip = (event: any) => {
      const tripData = event.detail;
      
      // Pre-fill the search query
      setSearchQuery({ 
        origin: tripData.origin, 
        destination: tripData.destination 
      });
      
      // If there was a selected route, restore it
      if (tripData.selectedRoute) {
        setSelectedRoute(tripData.selectedRoute);
        setShowTripDetails(true);
      } else {
        // Otherwise, trigger a search to show route options
        handleSearch([tripData.generateRoute || generateBasicRoute(tripData)], {
          origin: tripData.origin,
          destination: tripData.destination
        });
      }
    };

    window.addEventListener('resumeIncompleteTrip', handleResumeTrip);
    return () => window.removeEventListener('resumeIncompleteTrip', handleResumeTrip);
  }, []);

  const generateBasicRoute = (tripData: any) => {
    return {
      id: 'resumed-trip',
      mode: 'Bus',
      distance: tripData.estimatedDistance || 100,
      duration: tripData.estimatedDuration || 120,
      cost: tripData.estimatedCost || 200,
      coTravellers: tripData.coTravellers?.map((t: any) => t.fullName) || [],
      origin: tripData.origin,
      destination: tripData.destination,
    };
  };

  const handleSearch = (results: any[], query: { origin: string; destination: string }) => {
    setSearchResults(results);
    setSearchQuery(query);
    setShowResults(true);
    setShowTripDetails(false);
  };

  const handleRouteSelect = (route: any) => {
    setSelectedRoute(route);
    setShowTripDetails(true);
  };

  const handleBackToResults = () => {
    setShowTripDetails(false);
    setSelectedRoute(null);
  };

  const handleBackToPlanner = () => {
    setShowResults(false);
    setShowTripDetails(false);
    setSelectedRoute(null);
    setSearchResults([]);
  };

  return (
    <Layout>
      <div className="min-h-screen bg-background">
        <div className="container mx-auto px-4 py-6 max-w-4xl">
          {/* Welcome Header */}
          <div className="mb-6">
            <h1 className="text-3xl font-bold bg-gradient-travel bg-clip-text text-transparent mb-2">
              Welcome back, {user?.username}! 👋
            </h1>
            <p className="text-muted-foreground">
              Ready to plan your next amazing journey?
            </p>
          </div>

          {/* Incomplete Trip Banner */}
          {incompleteTrip && <IncompleteTripBanner />}

          {/* Main Content */}
          {!showResults && !showTripDetails && (
            <TripPlanner onSearch={handleSearch} />
          )}

          {showResults && !showTripDetails && (
            <RouteResults
              results={searchResults}
              origin={searchQuery.origin}
              destination={searchQuery.destination}
              onRouteSelect={handleRouteSelect}
              onBack={handleBackToPlanner}
            />
          )}

          {showTripDetails && selectedRoute && (
            <TripDetails
              route={selectedRoute}
              origin={searchQuery.origin}
              destination={searchQuery.destination}
              onBack={handleBackToResults}
              onComplete={handleBackToPlanner}
            />
          )}
        </div>
      </div>
    </Layout>
  );
};

export default Dashboard;