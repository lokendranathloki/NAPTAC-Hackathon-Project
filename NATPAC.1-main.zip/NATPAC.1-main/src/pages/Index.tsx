import { useAuth } from '@/contexts/AuthContext';
import { Navigate } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { MapPin, Plane } from 'lucide-react';
import { Link } from 'react-router-dom';

const Index = () => {
  const { isAuthenticated } = useAuth();

  if (isAuthenticated) {
    return <Navigate to="/dashboard" replace />;
  }

  return (
    <div className="min-h-screen bg-gradient-hero flex items-center justify-center p-4">
      <div className="text-center max-w-2xl">
        <div className="flex items-center justify-center gap-3 mb-6">
          <div className="relative">
            <MapPin className="h-12 w-12 text-white" />
            <Plane className="h-6 w-6 text-travel-orange absolute -top-2 -right-2" />
          </div>
          <h1 className="text-4xl font-bold text-white">NATPAC Travel</h1>
        </div>
        <p className="text-xl text-white/90 mb-8">
          Plan your perfect journey with smart route options, team collaboration, and community reviews
        </p>
        <div className="flex flex-col sm:flex-row gap-4 justify-center">
          <Link to="/register">
            <Button size="lg" className="bg-white text-primary hover:bg-white/90">
              Get Started
            </Button>
          </Link>
          <Link to="/login">
            <Button variant="outline" size="lg" className="border-white text-white hover:bg-white/10">
              Sign In
            </Button>
          </Link>
        </div>
      </div>
    </div>
  );
};

export default Index;
