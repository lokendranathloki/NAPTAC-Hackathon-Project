import { useState } from 'react';
import Layout from '@/components/Layout';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { ArrowLeft, HelpCircle, Phone, Mail, MessageSquare, ChevronDown, ChevronRight } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { toast } from '@/hooks/use-toast';
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from '@/components/ui/collapsible';

const Help = () => {
  const navigate = useNavigate();
  const [supportMessage, setSupportMessage] = useState('');
  const [supportEmail, setSupportEmail] = useState('');
  const [openFaq, setOpenFaq] = useState<string | null>(null);

  const faqs = [
    {
      id: 'how-to-plan',
      question: 'How do I plan a trip?',
      answer: 'Simply enter your origin and destination on the dashboard, click "Search Routes" to see available options, select your preferred route, and follow the trip details form to complete your planning.'
    },
    {
      id: 'incomplete-trips',
      question: 'What are incomplete trips?',
      answer: 'Incomplete trips are trips you started planning but haven\'t completed yet. You can save your progress and resume later. They appear as a banner on your dashboard with options to resume or discard.'
    },
    {
      id: 'add-review',
      question: 'How do I add a review?',
      answer: 'After completing a trip, go to Trip History and click "Add Review" on any completed trip. Fill out the review form to earn 10 points and help other travelers.'
    },
    {
      id: 'points-system',
      question: 'How does the points system work?',
      answer: 'You earn 10 points for each review you complete. Points determine your position on the leaderboard and show your contribution to the travel community.'
    },
    {
      id: 'team-travel',
      question: 'Can I plan trips with multiple people?',
      answer: 'Yes! When planning a trip, you can select team size (Solo, Duo, Squad, or Custom) and add details for co-travelers including their names, ages, and contact information.'
    },
    {
      id: 'upload-photos',
      question: 'How do I upload trip photos?',
      answer: 'During trip planning, you can upload 1-6 photos. Click the upload area, select your images (JPG/PNG), and they\'ll be saved with your trip for others to see in reviews.'
    },
    {
      id: 'delete-account',
      question: 'How do I delete my account?',
      answer: 'Go to Settings > Danger Zone and click "Delete Account". This action is permanent and will remove all your data including trips, reviews, and points.'
    },
    {
      id: 'notifications',
      question: 'How do I manage notifications?',
      answer: 'Visit the Notifications page from the menu to enable/disable notifications and customize which types of updates you want to receive.'
    }
  ];

  const handleSupportSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!supportEmail || !supportMessage) {
      toast({
        title: "Error",
        description: "Please fill in all fields",
        variant: "destructive",
      });
      return;
    }

    // In a real app, this would send to support system
    toast({
      title: "Support request sent!",
      description: "We'll get back to you within 24 hours.",
    });
    setSupportEmail('');
    setSupportMessage('');
  };

  return (
    <Layout>
      <div className="min-h-screen bg-background">
        <div className="container mx-auto px-4 py-6 max-w-4xl">
          {/* Header */}
          <div className="flex items-center gap-4 mb-6">
            <Button 
              variant="ghost" 
              size="sm" 
              onClick={() => navigate('/dashboard')}
              className="hover:bg-primary/10"
            >
              <ArrowLeft className="h-4 w-4 mr-2" />
              Back to Dashboard
            </Button>
          </div>

          <div className="mb-6">
            <h1 className="text-3xl font-bold bg-gradient-travel bg-clip-text text-transparent mb-2">
              Help & Support
            </h1>
            <p className="text-muted-foreground">
              Get help with your travel planning and app usage
            </p>
          </div>

          <div className="grid gap-6 lg:grid-cols-3">
            {/* Main Content */}
            <div className="lg:col-span-2 space-y-6">
              {/* FAQ Section */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <HelpCircle className="h-5 w-5" />
                    Frequently Asked Questions
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    {faqs.map((faq) => (
                      <Collapsible 
                        key={faq.id}
                        open={openFaq === faq.id}
                        onOpenChange={(open) => setOpenFaq(open ? faq.id : null)}
                      >
                        <CollapsibleTrigger asChild>
                          <Button 
                            variant="ghost" 
                            className="w-full justify-between text-left h-auto p-4 hover:bg-muted/50"
                          >
                            <span className="font-medium">{faq.question}</span>
                            {openFaq === faq.id ? (
                              <ChevronDown className="h-4 w-4" />
                            ) : (
                              <ChevronRight className="h-4 w-4" />
                            )}
                          </Button>
                        </CollapsibleTrigger>
                        <CollapsibleContent className="px-4 pb-4">
                          <p className="text-muted-foreground">{faq.answer}</p>
                        </CollapsibleContent>
                      </Collapsible>
                    ))}
                  </div>
                </CardContent>
              </Card>

              {/* Contact Support */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <MessageSquare className="h-5 w-5" />
                    Contact Support
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <form onSubmit={handleSupportSubmit} className="space-y-4">
                    <div>
                      <label htmlFor="support-email" className="text-sm font-medium">
                        Email Address
                      </label>
                      <Input
                        id="support-email"
                        type="email"
                        placeholder="your@email.com"
                        value={supportEmail}
                        onChange={(e) => setSupportEmail(e.target.value)}
                        required
                      />
                    </div>
                    <div>
                      <label htmlFor="support-message" className="text-sm font-medium">
                        How can we help you?
                      </label>
                      <Textarea
                        id="support-message"
                        placeholder="Describe your issue or question..."
                        rows={4}
                        value={supportMessage}
                        onChange={(e) => setSupportMessage(e.target.value)}
                        required
                      />
                    </div>
                    <Button type="submit" className="w-full">
                      Send Support Request
                    </Button>
                  </form>
                </CardContent>
              </Card>
            </div>

            {/* Sidebar */}
            <div className="space-y-6">
              {/* Quick Contact */}
              <Card>
                <CardHeader>
                  <CardTitle>Quick Contact</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="flex items-center gap-3">
                    <Phone className="h-5 w-5 text-primary" />
                    <div>
                      <p className="font-medium">Customer Care</p>
                      <p className="text-sm text-muted-foreground">+91-123-456-7890</p>
                    </div>
                  </div>
                  <div className="flex items-center gap-3">
                    <Mail className="h-5 w-5 text-primary" />
                    <div>
                      <p className="font-medium">Email Support</p>
                      <p className="text-sm text-muted-foreground">support@natpactravel.com</p>
                    </div>
                  </div>
                </CardContent>
              </Card>

              {/* App Issues */}
              <Card>
                <CardHeader>
                  <CardTitle>Report App Issues</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-sm text-muted-foreground mb-4">
                    Experiencing technical problems? Let us know so we can fix them quickly.
                  </p>
                  <Button variant="outline" className="w-full">
                    Report Bug
                  </Button>
                </CardContent>
              </Card>

              {/* App Version Info */}
              <Card>
                <CardHeader>
                  <CardTitle>App Information</CardTitle>
                </CardHeader>
                <CardContent className="space-y-2">
                  <div className="flex justify-between text-sm">
                    <span>Version</span>
                    <span>1.0.0</span>
                  </div>
                  <div className="flex justify-between text-sm">
                    <span>Platform</span>
                    <span>Web</span>
                  </div>
                  <div className="flex justify-between text-sm">
                    <span>Last Updated</span>
                    <span>Today</span>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </div>
    </Layout>
  );
};

export default Help;