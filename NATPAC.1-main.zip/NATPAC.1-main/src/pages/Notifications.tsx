import { useState, useEffect } from 'react';
import Layout from '@/components/Layout';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Switch } from '@/components/ui/switch';
import { Label } from '@/components/ui/label';
import { ArrowLeft, Bell, BellOff } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { toast } from '@/hooks/use-toast';

const Notifications = () => {
  const navigate = useNavigate();
  const [notificationsEnabled, setNotificationsEnabled] = useState(false);

  useEffect(() => {
    // Load notification preference from localStorage
    const saved = localStorage.getItem('travel_app_notifications_enabled');
    setNotificationsEnabled(saved === 'true');
  }, []);

  const handleToggleNotifications = (enabled: boolean) => {
    setNotificationsEnabled(enabled);
    localStorage.setItem('travel_app_notifications_enabled', enabled.toString());
    
    toast({
      title: enabled ? "Notifications enabled" : "Notifications disabled",
      description: enabled 
        ? "You'll receive updates about your trips and reviews."
        : "You won't receive any notifications from the app.",
    });
  };

  return (
    <Layout>
      <div className="min-h-screen bg-background">
        <div className="container mx-auto px-4 py-6 max-w-4xl">
          {/* Header */}
          <div className="flex items-center gap-4 mb-6">
            <Button 
              variant="ghost" 
              size="sm" 
              onClick={() => navigate('/dashboard')}
              className="hover:bg-primary/10"
            >
              <ArrowLeft className="h-4 w-4 mr-2" />
              Back to Dashboard
            </Button>
          </div>

          <div className="mb-6">
            <h1 className="text-3xl font-bold bg-gradient-travel bg-clip-text text-transparent mb-2">
              Notifications
            </h1>
            <p className="text-muted-foreground">
              Manage your notification preferences
            </p>
          </div>

          {/* Notification Settings */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                {notificationsEnabled ? <Bell className="h-5 w-5" /> : <BellOff className="h-5 w-5" />}
                Notification Settings
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-6">
              {/* Main Toggle */}
              <div className="flex items-center justify-between p-4 rounded-lg border bg-card">
                <div className="flex-1">
                  <Label htmlFor="notifications-toggle" className="text-base font-medium">
                    Enable Notifications
                  </Label>
                  <p className="text-sm text-muted-foreground mt-1">
                    Receive updates about your trips, reviews, and app features
                  </p>
                </div>
                <Switch
                  id="notifications-toggle"
                  checked={notificationsEnabled}
                  onCheckedChange={handleToggleNotifications}
                />
              </div>

              {/* Notification Types */}
              {notificationsEnabled && (
                <div className="space-y-4">
                  <h3 className="font-medium text-foreground">Notification Types</h3>
                  
                  <div className="space-y-3">
                    <div className="flex items-center justify-between">
                      <div>
                        <Label>Trip Updates</Label>
                        <p className="text-sm text-muted-foreground">
                          Get notified about trip status changes and reminders
                        </p>
                      </div>
                      <Switch defaultChecked />
                    </div>

                    <div className="flex items-center justify-between">
                      <div>
                        <Label>Review Reminders</Label>
                        <p className="text-sm text-muted-foreground">
                          Reminders to add reviews for completed trips
                        </p>
                      </div>
                      <Switch defaultChecked />
                    </div>

                    <div className="flex items-center justify-between">
                      <div>
                        <Label>Leaderboard Updates</Label>
                        <p className="text-sm text-muted-foreground">
                          Notifications about your ranking and achievements
                        </p>
                      </div>
                      <Switch defaultChecked />
                    </div>

                    <div className="flex items-center justify-between">
                      <div>
                        <Label>App Updates</Label>
                        <p className="text-sm text-muted-foreground">
                          Information about new features and updates
                        </p>
                      </div>
                      <Switch defaultChecked />
                    </div>

                    <div className="flex items-center justify-between">
                      <div>
                        <Label>Travel Tips</Label>
                        <p className="text-sm text-muted-foreground">
                          Weekly travel tips and destination recommendations
                        </p>
                      </div>
                      <Switch />
                    </div>
                  </div>
                </div>
              )}

              {!notificationsEnabled && (
                <div className="text-center py-8">
                  <BellOff className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
                  <h3 className="text-lg font-semibold mb-2">Notifications Disabled</h3>
                  <p className="text-muted-foreground">
                    Enable notifications to stay updated with your travel plans
                  </p>
                </div>
              )}
            </CardContent>
          </Card>

          {/* Recent Notifications (Mock) */}
          <Card className="mt-6">
            <CardHeader>
              <CardTitle>Recent Notifications</CardTitle>
            </CardHeader>
            <CardContent>
              {notificationsEnabled ? (
                <div className="space-y-3">
                  <div className="p-3 rounded-lg bg-muted/50">
                    <p className="text-sm font-medium">Welcome to NATPAC Travel! 🎉</p>
                    <p className="text-xs text-muted-foreground">2 hours ago</p>
                  </div>
                  <div className="p-3 rounded-lg bg-muted/30">
                    <p className="text-sm">Don't forget to add a review for your trip to boost your points!</p>
                    <p className="text-xs text-muted-foreground">1 day ago</p>
                  </div>
                </div>
              ) : (
                <p className="text-sm text-muted-foreground text-center py-4">
                  No recent notifications. Enable notifications to see updates here.
                </p>
              )}
            </CardContent>
          </Card>
        </div>
      </div>
    </Layout>
  );
};

export default Notifications;