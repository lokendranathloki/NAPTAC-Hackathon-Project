import { useState } from 'react';
import Layout from '@/components/Layout';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { Separator } from '@/components/ui/separator';
import { ArrowLeft, PartyPopper, Calendar, MapPin, Star, Mountain, Building, Waves, Camera } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { majorFestivals, districtFestivals, topTouristPlaces, districtTouristPlaces, getDistrictOptions } from '@/lib/festivalData';

const Festivals = () => {
  const navigate = useNavigate();
  const [selectedDistrict, setSelectedDistrict] = useState<string>('all');

  const getTypeIcon = (type: string) => {
    switch (type.toLowerCase()) {
      case 'monument':
      case 'fort':
        return <Building className="h-4 w-4" />;
      case 'natural':
      case 'mountain':
        return <Mountain className="h-4 w-4" />;
      case 'beach':
      case 'waterfront':
        return <Waves className="h-4 w-4" />;
      default:
        return <Camera className="h-4 w-4" />;
    }
  };

  const currentFestivals = selectedDistrict === 'all' ? majorFestivals : districtFestivals[selectedDistrict] || [];
  const currentTouristPlaces = selectedDistrict === 'all' ? topTouristPlaces : districtTouristPlaces[selectedDistrict] || [];

  return (
    <Layout>
      <div className="min-h-screen bg-background">
        <div className="container mx-auto px-4 py-6 max-w-6xl">
          {/* Header */}
          <div className="flex items-center gap-4 mb-6">
            <Button 
              variant="ghost" 
              size="sm" 
              onClick={() => navigate('/dashboard')}
              className="hover:bg-primary/10"
            >
              <ArrowLeft className="h-4 w-4 mr-2" />
              Back to Dashboard
            </Button>
          </div>

          <div className="mb-6">
            <h1 className="text-3xl font-bold bg-gradient-travel bg-clip-text text-transparent mb-2 flex items-center gap-2">
              <PartyPopper className="h-8 w-8 text-travel-orange" />
              Places & Festivals
            </h1>
            <p className="text-muted-foreground">
              Discover amazing festivals and tourist destinations across India
            </p>
          </div>

          {/* District Filter */}
          <Card className="mb-6">
            <CardContent className="pt-6">
              <div className="flex items-center gap-4">
                <div className="flex-1">
                  <label className="text-sm font-medium mb-2 block">
                    Filter by District
                  </label>
                  <Select value={selectedDistrict} onValueChange={setSelectedDistrict}>
                    <SelectTrigger className="w-full md:w-[280px]">
                      <SelectValue placeholder="All Districts" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">All Districts</SelectItem>
                      {getDistrictOptions().map((district) => (
                        <SelectItem key={district} value={district}>
                          {district}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                {selectedDistrict !== 'all' && (
                  <Button
                    variant="outline"
                    onClick={() => setSelectedDistrict('all')}
                    className="mt-6"
                  >
                    Clear Filter
                  </Button>
                )}
              </div>
            </CardContent>
          </Card>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* Festivals Section */}
            <div>
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <PartyPopper className="h-5 w-5 text-travel-orange" />
                    {selectedDistrict !== 'all' ? `Festivals in ${selectedDistrict}` : 'Major Festivals in India'}
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  {currentFestivals.length === 0 ? (
                    <div className="text-center py-8">
                      <PartyPopper className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
                      <h3 className="text-lg font-semibold mb-2">No festivals found</h3>
                      <p className="text-muted-foreground">
                        No festivals data available for this district.
                      </p>
                    </div>
                  ) : (
                    <div className="space-y-4">
                      {currentFestivals.map((festival, index) => (
                        <div key={index} className="border rounded-lg p-4 hover:shadow-md transition-shadow">
                          <div className="flex items-start justify-between mb-2">
                            <h3 className="font-semibold text-lg">{festival.name}</h3>
                            <Badge variant="secondary" className="bg-travel-orange/10 text-travel-orange">
                              <Calendar className="h-3 w-3 mr-1" />
                              {festival.month}
                            </Badge>
                          </div>
                          <p className="text-sm text-muted-foreground mb-2">
                            {festival.description}
                          </p>
                          <div className="flex items-center gap-4 text-sm">
                            <div className="flex items-center gap-1">
                              <Calendar className="h-3 w-3 text-primary" />
                              <span>{festival.date}</span>
                            </div>
                            <div className="flex items-center gap-1">
                              <MapPin className="h-3 w-3 text-primary" />
                              <span>{festival.location}</span>
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>
                  )}
                </CardContent>
              </Card>
            </div>

            {/* Tourist Places Section */}
            <div>
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Star className="h-5 w-5 text-yellow-500" />
                    {selectedDistrict !== 'all' ? `Tourist Places in ${selectedDistrict}` : 'Top Tourist Places in India'}
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  {currentTouristPlaces.length === 0 ? (
                    <div className="text-center py-8">
                      <Star className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
                      <h3 className="text-lg font-semibold mb-2">No places found</h3>
                      <p className="text-muted-foreground">
                        No tourist places data available for this district.
                      </p>
                    </div>
                  ) : (
                    <div className="space-y-4">
                      {currentTouristPlaces.map((place, index) => (
                        <div key={index} className="border rounded-lg p-4 hover:shadow-md transition-shadow">
                          <div className="flex items-start justify-between mb-2">
                            <h3 className="font-semibold text-lg">{place.name}</h3>
                            <Badge variant="outline" className="flex items-center gap-1">
                              {getTypeIcon(place.type)}
                              {place.type}
                            </Badge>
                          </div>
                          <p className="text-sm text-muted-foreground mb-2">
                            {place.description}
                          </p>
                          <div className="flex items-center gap-1 text-sm">
                            <MapPin className="h-3 w-3 text-primary" />
                            <span>{place.location}</span>
                          </div>
                        </div>
                      ))}
                    </div>
                  )}
                </CardContent>
              </Card>
            </div>
          </div>

          {/* Travel Planning CTA */}
          <Card className="mt-6 bg-gradient-card border-primary/20">
            <CardContent className="pt-6">
              <div className="text-center">
                <h3 className="text-xl font-semibold mb-2">
                  Plan Your Festival Trip! 🎉
                </h3>
                <p className="text-muted-foreground mb-4">
                  Discover routes to these amazing festivals and tourist places
                </p>
                <Button 
                  onClick={() => navigate('/dashboard')}
                  className="bg-gradient-button hover:shadow-travel"
                >
                  Start Planning Trip
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </Layout>
  );
};

export default Festivals;