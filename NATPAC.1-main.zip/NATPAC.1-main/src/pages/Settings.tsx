import { useState } from 'react';
import { useAuth } from '@/contexts/AuthContext';
import { useLanguage } from '@/contexts/LanguageContext';
import { useTheme } from '@/components/theme-provider';
import Layout from '@/components/Layout';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Switch } from '@/components/ui/switch';
import { Separator } from '@/components/ui/separator';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { ArrowLeft, User, Moon, Sun, Heart, Info, Trash2, Plus, MapPin, Globe } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { toast } from '@/hooks/use-toast';
import ProfilePictureUpload from '@/components/ProfilePictureUpload';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from '@/components/ui/alert-dialog';

const Settings = () => {
  const { user, updateUser, logout } = useAuth();
  const { theme, setTheme } = useTheme();
  const { language, setLanguage, t, availableLanguages } = useLanguage();
  const navigate = useNavigate();
  const [editingProfile, setEditingProfile] = useState(false);
  const [managingFavorites, setManagingFavorites] = useState(false);
  const [newFavorite, setNewFavorite] = useState('');
  const [favorites, setFavorites] = useState<string[]>(
    JSON.parse(localStorage.getItem(`favorites_${user?.id}`) || '[]')
  );
  const [profileData, setProfileData] = useState({
    username: user?.username || '',
    email: user?.email || '',
    fullName: user?.personalDetails?.fullName || '',
    phone: user?.personalDetails?.phone || '',
  });

  const handleProfileSave = () => {
    updateUser({
      username: profileData.username,
      email: profileData.email,
      personalDetails: {
        ...user?.personalDetails,
        fullName: profileData.fullName,
        phone: profileData.phone,
      },
    });
    setEditingProfile(false);
    toast({
      title: "Profile updated",
      description: "Your profile has been updated successfully.",
    });
  };

  const handleProfilePictureChange = (imageData: string | null) => {
    updateUser({
      profilePicture: imageData,
    });
  };

  const handleAddFavorite = () => {
    if (!newFavorite.trim()) {
      toast({
        title: "Enter location",
        description: "Please enter a location name",
        variant: "destructive",
      });
      return;
    }

    if (favorites.includes(newFavorite.trim())) {
      toast({
        title: "Already exists",
        description: "This location is already in your favorites",
        variant: "destructive",
      });
      return;
    }

    const updatedFavorites = [...favorites, newFavorite.trim()];
    setFavorites(updatedFavorites);
    localStorage.setItem(`favorites_${user?.id}`, JSON.stringify(updatedFavorites));
    setNewFavorite('');
    
    toast({
      title: "Favorite added",
      description: `${newFavorite.trim()} has been added to your favorites`,
    });
  };

  const handleRemoveFavorite = (location: string) => {
    const updatedFavorites = favorites.filter(fav => fav !== location);
    setFavorites(updatedFavorites);
    localStorage.setItem(`favorites_${user?.id}`, JSON.stringify(updatedFavorites));
    
    toast({
      title: "Favorite removed",
      description: `${location} has been removed from your favorites`,
    });
  };

  const handleDeleteAccount = () => {
    // Remove user data from localStorage
    localStorage.removeItem('travel_app_user');
    const users = JSON.parse(localStorage.getItem('travel_app_users') || '[]');
    const updatedUsers = users.filter((u: any) => u.id !== user?.id);
    localStorage.setItem('travel_app_users', JSON.stringify(updatedUsers));
    
    // Clear trip data for this user
    const trips = JSON.parse(localStorage.getItem('travel_app_completed_trips') || '[]');
    const userTrips = trips.filter((trip: any) => trip.userId !== user?.id);
    localStorage.setItem('travel_app_completed_trips', JSON.stringify(userTrips));
    
    logout();
    navigate('/');
    toast({
      title: "Account deleted",
      description: "Your account has been permanently deleted.",
    });
  };

  return (
    <Layout>
      <div className="min-h-screen bg-background">
        <div className="container mx-auto px-4 py-6 max-w-4xl">
          {/* Header */}
          <div className="flex items-center gap-4 mb-6">
            <Button 
              variant="ghost" 
              size="sm" 
              onClick={() => navigate('/dashboard')}
              className="hover:bg-primary/10"
            >
              <ArrowLeft className="h-4 w-4 mr-2" />
              Back to Dashboard
            </Button>
          </div>

          <div className="mb-6">
            <h1 className="text-3xl font-bold bg-gradient-travel bg-clip-text text-transparent mb-2">
              Settings
            </h1>
            <p className="text-muted-foreground">
              Manage your account and preferences
            </p>
          </div>

          <div className="space-y-6">
            {/* Profile Settings */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <User className="h-5 w-5" />
                  Profile Settings
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="mb-4">
                  <ProfilePictureUpload
                    currentImage={user?.profilePicture || user?.profileImage}
                    username={user?.username || ''}
                    onImageChange={handleProfilePictureChange}
                  />
                  <div className="mt-2">
                    <h3 className="font-semibold">{user?.username}</h3>
                    <p className="text-sm text-muted-foreground">{user?.points || 0} points</p>
                  </div>
                </div>

                <Separator />

                {editingProfile ? (
                  <div className="space-y-4">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div>
                        <Label htmlFor="username">Username</Label>
                        <Input
                          id="username"
                          value={profileData.username}
                          onChange={(e) => setProfileData({ ...profileData, username: e.target.value })}
                        />
                      </div>
                      <div>
                        <Label htmlFor="email">Email</Label>
                        <Input
                          id="email"
                          type="email"
                          value={profileData.email}
                          onChange={(e) => setProfileData({ ...profileData, email: e.target.value })}
                        />
                      </div>
                      <div>
                        <Label htmlFor="fullName">Full Name</Label>
                        <Input
                          id="fullName"
                          value={profileData.fullName}
                          onChange={(e) => setProfileData({ ...profileData, fullName: e.target.value })}
                        />
                      </div>
                      <div>
                        <Label htmlFor="phone">Phone</Label>
                        <Input
                          id="phone"
                          value={profileData.phone}
                          onChange={(e) => setProfileData({ ...profileData, phone: e.target.value })}
                        />
                      </div>
                    </div>
                    <div className="flex gap-2">
                      <Button onClick={handleProfileSave}>Save Changes</Button>
                      <Button variant="outline" onClick={() => setEditingProfile(false)}>
                        Cancel
                      </Button>
                    </div>
                  </div>
                ) : (
                  <div className="space-y-4">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div>
                        <Label>Username</Label>
                        <p className="text-sm font-medium">{user?.username}</p>
                      </div>
                      <div>
                        <Label>Email</Label>
                        <p className="text-sm font-medium">{user?.email}</p>
                      </div>
                      <div>
                        <Label>Full Name</Label>
                        <p className="text-sm font-medium">{user?.personalDetails?.fullName || 'Not set'}</p>
                      </div>
                      <div>
                        <Label>Phone</Label>
                        <p className="text-sm font-medium">{user?.personalDetails?.phone || 'Not set'}</p>
                      </div>
                    </div>
                    <Button onClick={() => setEditingProfile(true)}>Edit Profile</Button>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Appearance */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  {theme === 'dark' ? <Moon className="h-5 w-5" /> : <Sun className="h-5 w-5" />}
                  Appearance
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="flex items-center justify-between">
                  <div>
                    <Label htmlFor="dark-mode">Dark Mode</Label>
                    <p className="text-sm text-muted-foreground">
                      Switch between light and dark themes
                    </p>
                  </div>
                  <Switch
                    id="dark-mode"
                    checked={theme === 'dark'}
                    onCheckedChange={(checked) => setTheme(checked ? 'dark' : 'light')}
                  />
                </div>
              </CardContent>
            </Card>

            {/* Favorites Management */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Heart className="h-5 w-5" />
                  Favorites Management
                </CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-muted-foreground mb-4">
                  Save your favorite locations for quick access
                </p>
                
                {!managingFavorites ? (
                  <Button 
                    variant="outline" 
                    onClick={() => setManagingFavorites(true)}
                  >
                    Manage Favorites ({favorites.length})
                  </Button>
                ) : (
                  <div className="space-y-4">
                    {/* Add New Favorite */}
                    <div className="flex gap-2">
                      <Input
                        placeholder="Enter location name"
                        value={newFavorite}
                        onChange={(e) => setNewFavorite(e.target.value)}
                        onKeyPress={(e) => e.key === 'Enter' && handleAddFavorite()}
                      />
                      <Button onClick={handleAddFavorite} size="sm">
                        <Plus className="h-4 w-4 mr-1" />
                        Add
                      </Button>
                    </div>

                    {/* Favorites List */}
                    {favorites.length === 0 ? (
                      <div className="text-center py-6 text-muted-foreground">
                        <MapPin className="h-8 w-8 mx-auto mb-2" />
                        <p>No favorite locations yet</p>
                        <p className="text-sm">Add some places you visit frequently</p>
                      </div>
                    ) : (
                      <div className="space-y-2">
                        <Label className="text-sm font-medium">Your Favorites</Label>
                        {favorites.map((location, index) => (
                          <div key={index} className="flex items-center justify-between p-3 border rounded-lg">
                            <div className="flex items-center gap-2">
                              <MapPin className="h-4 w-4 text-primary" />
                              <span>{location}</span>
                            </div>
                            <Button
                              variant="ghost"
                              size="sm"
                              onClick={() => handleRemoveFavorite(location)}
                              className="text-destructive hover:text-destructive hover:bg-destructive/10"
                            >
                              Remove
                            </Button>
                          </div>
                        ))}
                      </div>
                    )}

                    <Button 
                      variant="outline" 
                      onClick={() => setManagingFavorites(false)}
                    >
                      Done
                    </Button>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* App Information */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Info className="h-5 w-5" />
                  About
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-2">
                  <div className="flex justify-between">
                    <span>App Version</span>
                    <span className="text-muted-foreground">1.0.0</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Platform</span>
                    <span className="text-muted-foreground">NATPAC Travel</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Member Since</span>
                    <span className="text-muted-foreground">
                      {user?.joinedAt ? new Date(user.joinedAt).toLocaleDateString() : 'N/A'}
                    </span>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Danger Zone */}
            <Card className="border-destructive/20">
              <CardHeader>
                <CardTitle className="flex items-center gap-2 text-destructive">
                  <Trash2 className="h-5 w-5" />
                  Danger Zone
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div>
                    <h4 className="font-medium">Delete Account</h4>
                    <p className="text-sm text-muted-foreground">
                      Permanently delete your account and all associated data. This action cannot be undone.
                    </p>
                  </div>
                  <AlertDialog>
                    <AlertDialogTrigger asChild>
                      <Button variant="destructive">Delete Account</Button>
                    </AlertDialogTrigger>
                    <AlertDialogContent>
                      <AlertDialogHeader>
                        <AlertDialogTitle>Are you absolutely sure?</AlertDialogTitle>
                        <AlertDialogDescription>
                          This action cannot be undone. This will permanently delete your account
                          and remove your data from our servers.
                        </AlertDialogDescription>
                      </AlertDialogHeader>
                      <AlertDialogFooter>
                        <AlertDialogCancel>Cancel</AlertDialogCancel>
                        <AlertDialogAction onClick={handleDeleteAccount} className="bg-destructive text-destructive-foreground hover:bg-destructive/90">
                          Delete Account
                        </AlertDialogAction>
                      </AlertDialogFooter>
                    </AlertDialogContent>
                  </AlertDialog>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </Layout>
  );
};

export default Settings;