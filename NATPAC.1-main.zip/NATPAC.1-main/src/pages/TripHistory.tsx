import { useState } from 'react';
import { useAuth } from '@/contexts/AuthContext';
import { useTrip } from '@/contexts/TripContext';
import Layout from '@/components/Layout';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { ArrowLeft, Calendar, MapPin, Users, Star, MessageSquare, Eye } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import TripReviewModal from '@/components/TripReviewModal';
import TripDetailsModal from '@/components/TripDetailsModal';

const TripHistory = () => {
  const { user } = useAuth();
  const { completedTrips } = useTrip();
  const navigate = useNavigate();
  const [selectedTrip, setSelectedTrip] = useState<any>(null);
  const [showReviewModal, setShowReviewModal] = useState(false);
  const [showDetailsModal, setShowDetailsModal] = useState(false);

  const userTrips = completedTrips.filter(trip => trip.userId === user?.id);

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('en-IN', {
      day: 'numeric',
      month: 'short',
      year: 'numeric'
    });
  };

  const formatDuration = (minutes: number) => {
    if (minutes < 60) return `${minutes}m`;
    const hours = Math.floor(minutes / 60);
    const remainingMinutes = minutes % 60;
    return remainingMinutes > 0 ? `${hours}h ${remainingMinutes}m` : `${hours}h`;
  };

  const handleAddReview = (trip: any) => {
    setSelectedTrip(trip);
    setShowReviewModal(true);
  };

  const handleViewDetails = (trip: any) => {
    setSelectedTrip(trip);
    setShowDetailsModal(true);
  };

  return (
    <Layout>
      <div className="min-h-screen bg-background">
        <div className="container mx-auto px-4 py-6 max-w-4xl">
          {/* Header */}
          <div className="flex items-center gap-4 mb-6">
            <Button 
              variant="ghost" 
              size="sm" 
              onClick={() => navigate('/dashboard')}
              className="hover:bg-primary/10"
            >
              <ArrowLeft className="h-4 w-4 mr-2" />
              Back to Dashboard
            </Button>
          </div>

          <div className="mb-6">
            <h1 className="text-3xl font-bold bg-gradient-travel bg-clip-text text-transparent mb-2">
              Trip History
            </h1>
            <p className="text-muted-foreground">
              {userTrips.length} completed trip{userTrips.length !== 1 ? 's' : ''}
            </p>
          </div>

          {/* Trip Cards */}
          <div className="space-y-4">
            {userTrips.length === 0 ? (
              <Card className="text-center py-12">
                <CardContent>
                  <MapPin className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
                  <h3 className="text-lg font-semibold mb-2">No trips yet</h3>
                  <p className="text-muted-foreground mb-4">
                    Start planning your first journey to see it here!
                  </p>
                  <Button onClick={() => navigate('/dashboard')}>
                    Plan Your First Trip
                  </Button>
                </CardContent>
              </Card>
            ) : (
              userTrips.map((trip) => (
                <Card key={trip.id} className="hover:shadow-card-hover transition-all duration-300">
                  <CardHeader>
                    <div className="flex items-start justify-between">
                      <div className="flex-1">
                        <CardTitle className="flex items-center gap-2 mb-2">
                          <MapPin className="h-5 w-5 text-primary" />
                          {trip.origin} → {trip.destination}
                        </CardTitle>
                        {trip.teamName && (
                          <p className="text-sm text-muted-foreground">"{trip.teamName}"</p>
                        )}
                      </div>
                      <div className="text-right">
                        <Badge variant="outline" className="mb-2">
                          <Calendar className="h-3 w-3 mr-1" />
                          {formatDate(trip.completedAt!)}
                        </Badge>
                      </div>
                    </div>
                  </CardHeader>
                  <CardContent>
                    <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-4">
                      <div>
                        <p className="text-sm text-muted-foreground">Mode</p>
                        <p className="font-medium">{trip.selectedRoute?.mode}</p>
                      </div>
                      <div>
                        <p className="text-sm text-muted-foreground">Distance</p>
                        <p className="font-medium">{trip.selectedRoute?.distance} km</p>
                      </div>
                      <div>
                        <p className="text-sm text-muted-foreground">Duration</p>
                        <p className="font-medium">{formatDuration(trip.selectedRoute?.duration || 0)}</p>
                      </div>
                      <div>
                        <p className="text-sm text-muted-foreground">Cost</p>
                        <p className="font-medium">₹{trip.selectedRoute?.cost}</p>
                      </div>
                    </div>

                    {trip.coTravellers && trip.coTravellers.length > 0 && (
                      <div className="mb-4">
                        <p className="text-sm text-muted-foreground mb-2">
                          <Users className="h-4 w-4 inline mr-1" />
                          Co-travelers ({trip.coTravellers.length})
                        </p>
                        <div className="flex flex-wrap gap-2">
                          {trip.coTravellers.slice(0, 3).map((traveller, index) => (
                            <Badge key={index} variant="secondary">
                              {traveller.fullName}
                            </Badge>
                          ))}
                          {trip.coTravellers.length > 3 && (
                            <Badge variant="secondary">
                              +{trip.coTravellers.length - 3} more
                            </Badge>
                          )}
                        </div>
                      </div>
                    )}

                    {trip.images && trip.images.length > 0 && (
                      <div className="mb-4">
                        <p className="text-sm text-muted-foreground mb-2">Photos</p>
                        <div className="flex gap-2 overflow-x-auto">
                          {trip.images.slice(0, 4).map((image, index) => (
                            <div key={index} className="flex-shrink-0">
                              <img
                                src={image}
                                alt={`Trip photo ${index + 1}`}
                                className="w-16 h-16 rounded-lg object-cover"
                              />
                            </div>
                          ))}
                          {trip.images.length > 4 && (
                            <div className="flex-shrink-0 w-16 h-16 rounded-lg bg-muted flex items-center justify-center text-xs text-muted-foreground">
                              +{trip.images.length - 4}
                            </div>
                          )}
                        </div>
                      </div>
                    )}

                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => handleViewDetails(trip)}
                          className="text-primary hover:bg-primary/10"
                        >
                          <Eye className="h-4 w-4 mr-2" />
                          View Details
                        </Button>
                        {trip.reviews && trip.reviews.length > 0 ? (
                          <Badge variant="secondary" className="text-travel-green">
                            <Star className="h-3 w-3 mr-1" />
                            Review Added
                          </Badge>
                        ) : (
                          <Button
                            variant="outline"
                            size="sm"
                            onClick={() => handleAddReview(trip)}
                            className="text-primary hover:bg-primary/10"
                          >
                            <MessageSquare className="h-4 w-4 mr-2" />
                            Add Review
                          </Button>
                        )}
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))
            )}
          </div>
        </div>
      </div>

      {/* Review Modal */}
      <TripReviewModal
        trip={selectedTrip}
        open={showReviewModal}
        onClose={() => {
          setShowReviewModal(false);
          setSelectedTrip(null);
        }}
      />

      {/* Trip Details Modal */}
      <TripDetailsModal
        trip={selectedTrip}
        open={showDetailsModal}
        onClose={() => {
          setShowDetailsModal(false);
          setSelectedTrip(null);
        }}
      />
    </Layout>
  );
};

export default TripHistory;