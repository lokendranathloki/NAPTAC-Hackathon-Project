import { useState, useEffect } from 'react';
import { useAuth } from '@/contexts/AuthContext';
import Layout from '@/components/Layout';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { ArrowLeft, Trophy, Medal, Award, Star } from 'lucide-react';
import { useNavigate } from 'react-router-dom';

interface LeaderboardUser {
  id: string;
  username: string;
  points: number;
  rank: number;
}

const Leaderboard = () => {
  const { user } = useAuth();
  const navigate = useNavigate();
  const [leaderboard, setLeaderboard] = useState<LeaderboardUser[]>([]);
  const [userRank, setUserRank] = useState<number | null>(null);

  useEffect(() => {
    // Load all users and calculate leaderboard
    const users = JSON.parse(localStorage.getItem('travel_app_users') || '[]');
    
    // Sort by points (descending) and add ranks
    const sortedUsers = users
      .map((u: any) => ({
        id: u.id,
        username: u.username,
        points: u.points || 0,
      }))
      .sort((a: any, b: any) => b.points - a.points)
      .map((u: any, index: number) => ({
        ...u,
        rank: index + 1,
      }));

    // Get top 10
    setLeaderboard(sortedUsers.slice(0, 10));
    
    // Find current user's rank
    const currentUserIndex = sortedUsers.findIndex((u: any) => u.id === user?.id);
    setUserRank(currentUserIndex !== -1 ? currentUserIndex + 1 : null);
  }, [user?.id]);

  const getRankIcon = (rank: number) => {
    switch (rank) {
      case 1:
        return <Trophy className="h-6 w-6 text-yellow-500" />;
      case 2:
        return <Medal className="h-6 w-6 text-gray-400" />;
      case 3:
        return <Award className="h-6 w-6 text-orange-500" />;
      default:
        return <div className="h-6 w-6 flex items-center justify-center text-sm font-bold text-muted-foreground">#{rank}</div>;
    }
  };

  const getRankBadgeColor = (rank: number) => {
    switch (rank) {
      case 1:
        return "bg-yellow-500 text-yellow-900";
      case 2:
        return "bg-gray-400 text-gray-900";
      case 3:
        return "bg-orange-500 text-orange-900";
      default:
        return "bg-muted text-muted-foreground";
    }
  };

  return (
    <Layout>
      <div className="min-h-screen bg-background">
        <div className="container mx-auto px-4 py-6 max-w-4xl">
          {/* Header */}
          <div className="flex items-center gap-4 mb-6">
            <Button 
              variant="ghost" 
              size="sm" 
              onClick={() => navigate('/dashboard')}
              className="hover:bg-primary/10"
            >
              <ArrowLeft className="h-4 w-4 mr-2" />
              Back to Dashboard
            </Button>
          </div>

          <div className="mb-6">
            <h1 className="text-3xl font-bold bg-gradient-travel bg-clip-text text-transparent mb-2">
              Leaderboard 🏆
            </h1>
            <p className="text-muted-foreground">
              Top travelers ranked by review contributions
            </p>
          </div>

          {/* Current User Rank */}
          {userRank && (
            <Card className="mb-6 border-primary/20 bg-gradient-card">
              <CardContent className="pt-4">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <div className="h-12 w-12 rounded-full bg-gradient-travel flex items-center justify-center text-white font-bold">
                      {user?.username?.[0]?.toUpperCase()}
                    </div>
                    <div>
                      <h3 className="font-semibold">{user?.username}</h3>
                      <p className="text-sm text-muted-foreground">Your current rank</p>
                    </div>
                  </div>
                  <div className="text-right">
                    <div className="flex items-center gap-2 mb-1">
                      {getRankIcon(userRank)}
                      <span className="text-lg font-bold">#{userRank}</span>
                    </div>
                    <Badge variant="secondary" className="bg-primary/10 text-primary">
                      <Star className="h-3 w-3 mr-1" />
                      {user?.points || 0} points
                    </Badge>
                  </div>
                </div>
              </CardContent>
            </Card>
          )}

          {/* Leaderboard */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Trophy className="h-5 w-5 text-yellow-500" />
                Top 10 Travelers
              </CardTitle>
            </CardHeader>
            <CardContent>
              {leaderboard.length === 0 ? (
                <div className="text-center py-8">
                  <Trophy className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
                  <h3 className="text-lg font-semibold mb-2">No rankings yet</h3>
                  <p className="text-muted-foreground">
                    Be the first to add reviews and climb the leaderboard!
                  </p>
                </div>
              ) : (
                <div className="space-y-3">
                  {leaderboard.map((leaderUser) => (
                    <div
                      key={leaderUser.id}
                      className={`flex items-center justify-between p-4 rounded-lg border transition-all duration-200 ${
                        leaderUser.id === user?.id 
                          ? 'bg-primary/5 border-primary/20' 
                          : 'bg-card hover:bg-card-hover'
                      }`}
                    >
                      <div className="flex items-center gap-4">
                        <div className="flex items-center gap-2">
                          {getRankIcon(leaderUser.rank)}
                        </div>
                        <div className="flex items-center gap-3">
                          <div className={`h-10 w-10 rounded-full flex items-center justify-center text-white font-bold ${
                            leaderUser.rank <= 3 ? 'bg-gradient-travel' : 'bg-muted'
                          }`}>
                            {leaderUser.username[0]?.toUpperCase()}
                          </div>
                          <div>
                            <h4 className="font-semibold flex items-center gap-2">
                              {leaderUser.username}
                              {leaderUser.id === user?.id && (
                                <Badge variant="outline" className="text-xs">You</Badge>
                              )}
                            </h4>
                            <p className="text-sm text-muted-foreground">
                              {leaderUser.points === 0 
                                ? 'No reviews yet' 
                                : `${Math.floor(leaderUser.points / 10)} review${Math.floor(leaderUser.points / 10) !== 1 ? 's' : ''}`
                              }
                            </p>
                          </div>
                        </div>
                      </div>
                      <div className="text-right">
                        <Badge className={getRankBadgeColor(leaderUser.rank)}>
                          <Star className="h-3 w-3 mr-1" />
                          {leaderUser.points} points
                        </Badge>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>

          {/* Points Info */}
          <Card className="mt-6">
            <CardHeader>
              <CardTitle>How to Earn Points</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                <div className="flex items-center gap-3">
                  <div className="h-8 w-8 rounded-full bg-travel-green flex items-center justify-center">
                    <Star className="h-4 w-4 text-white" />
                  </div>
                  <div>
                    <p className="font-medium">Complete a trip review</p>
                    <p className="text-sm text-muted-foreground">+10 points</p>
                  </div>
                </div>
                <p className="text-sm text-muted-foreground">
                  Share your travel experiences to help other travelers and climb the leaderboard!
                </p>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </Layout>
  );
};

export default Leaderboard;