import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Star, User, Calendar, MapPin } from 'lucide-react';

interface Review {
  id: string;
  userId: string;
  username: string;
  tripId: string;
  rating: number;
  roadCondition: string;
  trafficCongestion: string;
  safety: string;
  publicTransport: string;
  travelCost: string;
  pedestrianFacility: string;
  delays: string;
  satisfaction: string;
  improvements: string[];
  additionalSuggestions?: string;
  createdAt: string;
}

interface PastReviewsProps {
  reviews: Review[];
  origin: string;
  destination: string;
}

const PastReviews: React.FC<PastReviewsProps> = ({ reviews, origin, destination }) => {
  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('en-IN', {
      day: 'numeric',
      month: 'short',
      year: 'numeric'
    });
  };

  const getRatingColor = (rating: number) => {
    if (rating >= 4) return 'text-green-600';
    if (rating >= 3) return 'text-yellow-600';
    return 'text-red-600';
  };

  if (reviews.length === 0) {
    return (
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Star className="h-5 w-5 text-yellow-500" />
            Past Reviews for this Route
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="text-center py-8">
            <Star className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
            <h3 className="text-lg font-semibold mb-2">No reviews available</h3>
            <p className="text-muted-foreground">
              Be the first to travel this route and share your experience!
            </p>
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Star className="h-5 w-5 text-yellow-500" />
          Past Reviews for this Route ({reviews.length})
        </CardTitle>
        <p className="text-sm text-muted-foreground">
          See what other travelers experienced on the {origin} → {destination} route
        </p>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          {reviews.map((review) => (
            <div key={review.id} className="border rounded-lg p-4 bg-card">
              <div className="flex items-start justify-between mb-3">
                <div className="flex items-center gap-3">
                  <div className="h-10 w-10 rounded-full bg-gradient-travel flex items-center justify-center text-white font-bold text-sm">
                    {review.username[0]?.toUpperCase()}
                  </div>
                  <div>
                    <p className="font-medium">{review.username}</p>
                    <p className="text-sm text-muted-foreground">
                      <Calendar className="h-3 w-3 inline mr-1" />
                      {formatDate(review.createdAt)}
                    </p>
                  </div>
                </div>
                <div className="text-right">
                  <div className="flex items-center gap-1">
                    <Star className={`h-4 w-4 ${getRatingColor(5)}`} fill="currentColor" />
                    <span className="text-sm font-medium">Overall Satisfied</span>
                  </div>
                </div>
              </div>

              <div className="grid grid-cols-2 md:grid-cols-4 gap-3 mb-3">
                <div>
                  <p className="text-xs text-muted-foreground">Road Condition</p>
                  <Badge variant="secondary" className="text-xs">
                    {review.roadCondition}
                  </Badge>
                </div>
                <div>
                  <p className="text-xs text-muted-foreground">Traffic</p>
                  <Badge variant="secondary" className="text-xs">
                    {review.trafficCongestion}
                  </Badge>
                </div>
                <div>
                  <p className="text-xs text-muted-foreground">Safety</p>
                  <Badge variant="secondary" className="text-xs">
                    {review.safety}
                  </Badge>
                </div>
                <div>
                  <p className="text-xs text-muted-foreground">Cost</p>
                  <Badge variant="secondary" className="text-xs">
                    {review.travelCost}
                  </Badge>
                </div>
              </div>

              {review.improvements && review.improvements.length > 0 && (
                <div className="mb-2">
                  <p className="text-xs text-muted-foreground mb-1">Suggested Improvements:</p>
                  <div className="flex flex-wrap gap-1">
                    {review.improvements.slice(0, 3).map((improvement, index) => (
                      <Badge key={index} variant="outline" className="text-xs">
                        {improvement}
                      </Badge>
                    ))}
                    {review.improvements.length > 3 && (
                      <Badge variant="outline" className="text-xs">
                        +{review.improvements.length - 3} more
                      </Badge>
                    )}
                  </div>
                </div>
              )}

              {review.additionalSuggestions && (
                <div className="mt-2 p-2 bg-muted/50 rounded text-sm">
                  <p className="text-xs text-muted-foreground mb-1">Additional Tips:</p>
                  <p>"{review.additionalSuggestions}"</p>
                </div>
              )}
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  );
};

export default PastReviews;