import { useState } from 'react';
import { useTrip } from '@/contexts/TripContext';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { ArrowLeft, Clock, MapPin, IndianRupee, Users, ExternalLink, Star } from 'lucide-react';
import PastReviews from './PastReviews';

interface RouteResultsProps {
  results: any[];
  origin: string;
  destination: string;
  onRouteSelect: (route: any) => void;
  onBack: () => void;
}

const RouteResults: React.FC<RouteResultsProps> = ({ 
  results, 
  origin, 
  destination, 
  onRouteSelect, 
  onBack 
}) => {
  const [selectedRoute, setSelectedRoute] = useState<string | null>(null);
  const { getReviewsForRoute } = useTrip();

  const formatDuration = (minutes: number) => {
    if (minutes < 60) return `${minutes}m`;
    const hours = Math.floor(minutes / 60);
    const remainingMinutes = minutes % 60;
    return remainingMinutes > 0 ? `${hours}h ${remainingMinutes}m` : `${hours}h`;
  };

  const getModeText = (mode: string) => {
    switch (mode.toLowerCase()) {
      case 'bus': return 'Bus';
      case 'train': return 'Train';
      case 'car': return 'Car';
      case 'bike': return 'Bike';
      case 'walking': return 'Walking';
      case 'auto rickshaw': return 'Auto Rickshaw';
      case 'metro': return 'Metro';
      case 'taxi': return 'Taxi';
      default: return 'Car';
    }
  };

  const getModeColor = (mode: string) => {
    switch (mode.toLowerCase()) {
      case 'bus': return 'bg-blue-100 text-blue-800 border-blue-200';
      case 'train': return 'bg-green-100 text-green-800 border-green-200';
      case 'car': return 'bg-yellow-100 text-yellow-800 border-yellow-200';
      case 'bike': return 'bg-orange-100 text-orange-800 border-orange-200';
      case 'walking': return 'bg-gray-100 text-gray-800 border-gray-200';
      case 'auto rickshaw': return 'bg-purple-100 text-purple-800 border-purple-200';
      case 'metro': return 'bg-red-100 text-red-800 border-red-200';
      case 'taxi': return 'bg-indigo-100 text-indigo-800 border-indigo-200';
      default: return 'bg-gray-100 text-gray-800 border-gray-200';
    }
  };

  const handleViewOnMap = async (route: any) => {
    try {
      const { openInGoogleMaps } = await import('@/lib/googleMaps');
      await openInGoogleMaps(origin, destination, route.mode);
    } catch (error) {
      console.error('Error opening map:', error);
      alert('Unable to open Google Maps. Please check if the origin and destination are valid locations.');
    }
  };

  const handleRouteSelect = (route: any) => {
    setSelectedRoute(route.id);
    onRouteSelect(route);
  };

  const pastReviews = getReviewsForRoute(origin, destination);

  return (
    <div className="space-y-6 animate-slide-up">
      {/* Header */}
      <div className="flex items-center gap-4">
        <Button variant="ghost" size="sm" onClick={onBack} className="hover:bg-primary/10">
          <ArrowLeft className="h-4 w-4 mr-2" />
          Back to Search
        </Button>
      </div>

      <div>
        <h2 className="text-2xl font-bold bg-gradient-travel bg-clip-text text-transparent mb-2">
          Route Options
        </h2>
        <p className="text-muted-foreground flex items-center gap-2">
          <MapPin className="h-4 w-4" />
          {origin} → {destination} • {results.length} options available
        </p>
      </div>

      {/* Route Cards */}
      <div className="grid gap-4">
        {results.map((route, index) => (
          <Card 
            key={route.id} 
            className={`hover:shadow-card-hover transition-all duration-300 cursor-pointer ${
              selectedRoute === route.id ? 'ring-2 ring-primary shadow-travel' : ''
            }`}
            onClick={() => setSelectedRoute(route.id)}
          >
            <CardHeader className="pb-3">
              <div className="flex items-center justify-between">
                <CardTitle className="flex items-center gap-3">
                  <div>
                    <Badge className={getModeColor(route.mode)}>
                      {getModeText(route.mode)}
                    </Badge>
                    {index === 0 && (
                      <Badge variant="secondary" className="ml-2 bg-travel-green/10 text-travel-green">
                        <Star className="h-3 w-3 mr-1" />
                        Recommended
                      </Badge>
                    )}
                  </div>
                </CardTitle>
                <div className="text-right">
                  <p className="text-2xl font-bold text-primary">₹{route.cost}</p>
                  <p className="text-xs text-muted-foreground">per person</p>
                </div>
              </div>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-3 gap-4 mb-4">
                <div className="text-center">
                  <div className="flex items-center justify-center gap-1 text-muted-foreground mb-1">
                    <MapPin className="h-3 w-3" />
                    <span className="text-xs">Distance</span>
                  </div>
                  <p className="font-semibold">{route.distance} km</p>
                </div>
                <div className="text-center">
                  <div className="flex items-center justify-center gap-1 text-muted-foreground mb-1">
                    <Clock className="h-3 w-3" />
                    <span className="text-xs">Duration</span>
                  </div>
                  <p className="font-semibold">{formatDuration(route.duration)}</p>
                </div>
                <div className="text-center">
                  <div className="flex items-center justify-center gap-1 text-muted-foreground mb-1">
                    <Users className="h-3 w-3" />
                    <span className="text-xs">Co-travelers</span>
                  </div>
                  <p className="font-semibold">{route.coTravellers.length}</p>
                </div>
              </div>

              {/* Sample co-travellers */}
              <div className="mb-4">
                <p className="text-sm text-muted-foreground mb-2">Sample co-travelers on this route:</p>
                <div className="flex flex-wrap gap-1">
                  {route.coTravellers.slice(0, 4).map((name: string, idx: number) => (
                    <Badge key={idx} variant="secondary" className="text-xs">
                      {name}
                    </Badge>
                  ))}
                  {route.coTravellers.length > 4 && (
                    <Badge variant="secondary" className="text-xs">
                      +{route.coTravellers.length - 4} more
                    </Badge>
                  )}
                </div>
              </div>

              <div className="flex gap-2">
                <Button
                  onClick={(e) => {
                    e.stopPropagation();
                    handleRouteSelect(route);
                  }}
                  className="flex-1"
                  variant={selectedRoute === route.id ? "default" : "outline"}
                >
                  {selectedRoute === route.id ? "Selected" : "Select Route"}
                </Button>
                <Button
                  variant="outline"
                  size="sm"
                  onClick={(e) => {
                    e.stopPropagation();
                    handleViewOnMap(route);
                  }}
                >
                  <ExternalLink className="h-3 w-3 mr-1" />
                  Map
                </Button>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Continue Button */}
      {selectedRoute && (
        <Card className="border-primary/20 bg-primary/5 animate-scale-in">
          <CardContent className="pt-4">
            <div className="text-center">
              <p className="text-sm text-muted-foreground mb-3">
                Route selected! Ready to add team details and complete your trip planning.
              </p>
              <Button 
                onClick={() => {
                  const route = results.find(r => r.id === selectedRoute);
                  if (route) handleRouteSelect(route);
                }}
                className="bg-gradient-button hover:shadow-travel"
                size="lg"
              >
                Continue to Trip Details →
              </Button>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Past Reviews */}
      <PastReviews reviews={pastReviews} origin={origin} destination={destination} />
    </div>
  );
};

export default RouteResults;