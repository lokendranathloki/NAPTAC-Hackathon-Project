import { useState } from 'react';
import { useAuth } from '@/contexts/AuthContext';
import { Button } from '@/components/ui/button';
import { Sheet, SheetContent, SheetTrigger } from '@/components/ui/sheet';
import { Menu, MapPin, Plane, History, Settings, Bell, HelpCircle, Trophy, LogOut, PartyPopper, Users } from 'lucide-react';
import { useNavigate, useLocation } from 'react-router-dom';
import { toast } from '@/hooks/use-toast';

interface LayoutProps {
  children: React.ReactNode;
}

const Layout: React.FC<LayoutProps> = ({ children }) => {
  const { user, logout } = useAuth();
  const navigate = useNavigate();
  const location = useLocation();
  const [sidebarOpen, setSidebarOpen] = useState(false);

  const handleLogout = () => {
    logout();
    navigate('/');
    toast({
      title: "Logged out",
      description: "You have been successfully logged out.",
    });
  };

  const menuItems = [
    { icon: History, label: 'Trip History', path: '/trip-history' },
    { icon: PartyPopper, label: 'Places & Festivals', path: '/festivals' },
    { icon: Trophy, label: 'Leaderboard', path: '/leaderboard' },
    { icon: Bell, label: 'Notifications', path: '/notifications' },
    { icon: Settings, label: 'Settings', path: '/settings' },
    { icon: HelpCircle, label: 'Help & Support', path: '/help' },
  ];

  const handleNavigation = (path: string) => {
    navigate(path);
    setSidebarOpen(false);
  };

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="sticky top-0 z-50 bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60 border-b">
        <div className="container mx-auto px-4 h-16 flex items-center">
          <Sheet open={sidebarOpen} onOpenChange={setSidebarOpen}>
            <SheetTrigger asChild>
              <Button variant="ghost" size="sm" className="mr-4">
                <Menu className="h-5 w-5" />
              </Button>
            </SheetTrigger>
            <SheetContent side="left" className="w-80">
              <div className="flex flex-col h-full">
                {/* Header */}
                <div className="flex items-center gap-3 pb-6 border-b">
                  <div className="relative">
                    <MapPin className="h-8 w-8 text-primary" />
                    <Plane className="h-4 w-4 text-travel-orange absolute -top-1 -right-1" />
                  </div>
                  <div>
                    <h2 className="text-lg font-bold">NATPAC Travel</h2>
                    <p className="text-sm text-muted-foreground">Welcome, {user?.username}</p>
                  </div>
                </div>

                {/* User Info */}
                <div className="py-4 border-b">
                  <div className="flex items-center gap-3">
                    <div className="h-12 w-12 rounded-full bg-gradient-travel flex items-center justify-center text-white font-bold">
                      {user?.username?.[0]?.toUpperCase()}
                    </div>
                    <div>
                      <p className="font-medium">{user?.username}</p>
                      <p className="text-sm text-muted-foreground">{user?.points || 0} points</p>
                    </div>
                  </div>
                </div>

                {/* Navigation Menu */}
                <nav className="flex-1 py-4">
                  <div className="space-y-2">
                    {menuItems.map((item) => (
                      <Button
                        key={item.path}
                        variant={location.pathname === item.path ? "secondary" : "ghost"}
                        className="w-full justify-start"
                        onClick={() => handleNavigation(item.path)}
                      >
                        <item.icon className="h-4 w-4 mr-3" />
                        {item.label}
                      </Button>
                    ))}
                  </div>
                </nav>

                {/* Footer */}
                <div className="border-t pt-4">
                  <Button
                    variant="ghost"
                    className="w-full justify-start text-destructive hover:text-destructive hover:bg-destructive/10"
                    onClick={handleLogout}
                  >
                    <LogOut className="h-4 w-4 mr-3" />
                    Logout
                  </Button>
                </div>
              </div>
            </SheetContent>
          </Sheet>

          {/* App Title */}
          <div className="flex items-center gap-2 cursor-pointer" onClick={() => navigate('/dashboard')}>
            <div className="relative">
              <MapPin className="h-6 w-6 text-primary" />
              <Plane className="h-3 w-3 text-travel-orange absolute -top-0.5 -right-0.5" />
            </div>
            <h1 className="text-xl font-bold bg-gradient-travel bg-clip-text text-transparent">
              NATPAC Travel
            </h1>
          </div>

          {/* Navbar Buttons */}
          <div className="ml-auto flex items-center gap-2">
            <Button
              variant="ghost"
              size="sm"
              onClick={() => navigate('/festivals')}
              className="hidden md:flex items-center gap-2 hover:bg-primary/10"
            >
              <PartyPopper className="h-4 w-4 text-travel-orange" />
              Places & Festivals
            </Button>
            
            <Button
              variant="ghost"
              size="sm"
              onClick={() => navigate('/leaderboard')}
              className="hidden md:flex items-center gap-2 hover:bg-primary/10"
            >
              <Trophy className="h-4 w-4 text-yellow-500" />
              Leaderboard
            </Button>

            {/* User Info (Desktop) */}
            <div className="hidden md:flex items-center gap-3 ml-4">
              <div className="text-right">
                <p className="text-sm font-medium">{user?.username}</p>
                <p className="text-xs text-muted-foreground">{user?.points || 0} points</p>
              </div>
              <div className="h-8 w-8 rounded-full bg-gradient-travel flex items-center justify-center text-white font-bold text-sm">
                {user?.username?.[0]?.toUpperCase()}
              </div>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main>{children}</main>
    </div>
  );
};

export default Layout;