import React from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent } from '@/components/ui/card';
import { MapPin, Clock, Route, IndianRupee, Users, Calendar, X } from 'lucide-react';

interface Trip {
  id: string;
  userId: string;
  origin: string;
  destination: string;
  selectedRoute?: {
    mode: string;
    distance: number;
    duration: number;
    cost: number;
  };
  teamName?: string;
  tripTagline?: string;
  coTravellers: any[];
  images: string[];
  status: 'incomplete' | 'completed';
  createdAt: string;
  completedAt?: string;
}

interface TripDetailsModalProps {
  trip: Trip | null;
  open: boolean;
  onClose: () => void;
}

const TripDetailsModal: React.FC<TripDetailsModalProps> = ({ trip, open, onClose }) => {
  if (!trip) return null;

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('en-IN', {
      day: 'numeric',
      month: 'long',
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  const formatDuration = (minutes: number) => {
    if (minutes < 60) return `${minutes}m`;
    const hours = Math.floor(minutes / 60);
    const remainingMinutes = minutes % 60;
    return remainingMinutes > 0 ? `${hours}h ${remainingMinutes}m` : `${hours}h`;
  };

  const calculateAverageSpeed = () => {
    if (!trip.selectedRoute) return 0;
    const { distance, duration } = trip.selectedRoute;
    if (duration === 0) return 0;
    const hours = duration / 60;
    return Math.round(distance / hours);
  };

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <div className="flex items-center justify-between">
            <DialogTitle className="flex items-center gap-2">
              <MapPin className="h-5 w-5 text-primary" />
              Trip Details
            </DialogTitle>
            <Button variant="ghost" size="sm" onClick={onClose}>
              <X className="h-4 w-4" />
            </Button>
          </div>
        </DialogHeader>

        <div className="space-y-6">
          {/* Route Information */}
          <Card>
            <CardContent className="pt-6">
              <div className="flex items-center gap-2 mb-4">
                <Route className="h-5 w-5 text-primary" />
                <h3 className="text-lg font-semibold">Route Information</h3>
              </div>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
                <div>
                  <p className="text-sm text-muted-foreground">From</p>
                  <p className="font-medium">{trip.origin}</p>
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">To</p>
                  <p className="font-medium">{trip.destination}</p>
                </div>
              </div>

              {trip.selectedRoute && (
                <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                  <div>
                    <p className="text-sm text-muted-foreground">Mode</p>
                    <Badge variant="secondary">{trip.selectedRoute.mode}</Badge>
                  </div>
                  <div>
                    <p className="text-sm text-muted-foreground">Distance</p>
                    <p className="font-medium">{trip.selectedRoute.distance} km</p>
                  </div>
                  <div>
                    <p className="text-sm text-muted-foreground">Duration</p>
                    <p className="font-medium">{formatDuration(trip.selectedRoute.duration)}</p>
                  </div>
                  <div>
                    <p className="text-sm text-muted-foreground">Avg Speed</p>
                    <p className="font-medium">{calculateAverageSpeed()} km/h</p>
                  </div>
                </div>
              )}
            </CardContent>
          </Card>

          {/* Trip Details */}
          <Card>
            <CardContent className="pt-6">
              <div className="flex items-center gap-2 mb-4">
                <Calendar className="h-5 w-5 text-primary" />
                <h3 className="text-lg font-semibold">Trip Details</h3>
              </div>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <p className="text-sm text-muted-foreground">Started</p>
                  <p className="font-medium">{formatDate(trip.createdAt)}</p>
                </div>
                {trip.completedAt && (
                  <div>
                    <p className="text-sm text-muted-foreground">Completed</p>
                    <p className="font-medium">{formatDate(trip.completedAt)}</p>
                  </div>
                )}
                {trip.selectedRoute && (
                  <div>
                    <p className="text-sm text-muted-foreground">Total Cost</p>
                    <p className="font-medium flex items-center">
                      <IndianRupee className="h-4 w-4" />
                      {trip.selectedRoute.cost}
                    </p>
                  </div>
                )}
                <div>
                  <p className="text-sm text-muted-foreground">Status</p>
                  <Badge variant={trip.status === 'completed' ? 'default' : 'secondary'}>
                    {trip.status === 'completed' ? 'Completed' : 'Incomplete'}
                  </Badge>
                </div>
              </div>

              {trip.teamName && (
                <div className="mt-4">
                  <p className="text-sm text-muted-foreground">Team Name</p>
                  <p className="font-medium">{trip.teamName}</p>
                </div>
              )}

              {trip.tripTagline && (
                <div className="mt-4">
                  <p className="text-sm text-muted-foreground">Trip Tagline</p>
                  <p className="font-medium italic">"{trip.tripTagline}"</p>
                </div>
              )}
            </CardContent>
          </Card>

          {/* Co-Travellers */}
          {trip.coTravellers && trip.coTravellers.length > 0 && (
            <Card>
              <CardContent className="pt-6">
                <div className="flex items-center gap-2 mb-4">
                  <Users className="h-5 w-5 text-primary" />
                  <h3 className="text-lg font-semibold">Co-Travellers ({trip.coTravellers.length})</h3>
                </div>
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {trip.coTravellers.map((traveller, index) => (
                    <div key={index} className="p-3 border rounded-lg">
                      <p className="font-medium">{traveller.fullName}</p>
                      {traveller.age && (
                        <p className="text-sm text-muted-foreground">Age: {traveller.age}</p>
                      )}
                      {traveller.relationship && (
                        <p className="text-sm text-muted-foreground">Relation: {traveller.relationship}</p>
                      )}
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          )}

          {/* Trip Images */}
          {trip.images && trip.images.length > 0 && (
            <Card>
              <CardContent className="pt-6">
                <h3 className="text-lg font-semibold mb-4">Trip Photos ({trip.images.length})</h3>
                <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
                  {trip.images.map((image, index) => (
                    <div key={index} className="relative group">
                      <img
                        src={image}
                        alt={`Trip photo ${index + 1}`}
                        className="w-full h-24 object-cover rounded-lg cursor-pointer hover:opacity-75 transition-opacity"
                        onClick={() => window.open(image, '_blank')}
                      />
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          )}
        </div>
      </DialogContent>
    </Dialog>
  );
};

export default TripDetailsModal;