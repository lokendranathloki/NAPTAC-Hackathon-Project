import { useState } from 'react';
import { useAuth } from '@/contexts/AuthContext';
import { useTrip } from '@/contexts/TripContext';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Badge } from '@/components/ui/badge';
import { ArrowLeft, Users, Camera, Plus, X, Save, Check } from 'lucide-react';
import { toast } from '@/hooks/use-toast';

interface TripDetailsProps {
  route: any;
  origin: string;
  destination: string;
  onBack: () => void;
  onComplete: () => void;
}

interface CoTraveller {
  fullName: string;
  dateOfBirth?: string;
  age?: number;
  gender?: string;
  relationship?: string;
  contact?: string;
}

const TripDetails: React.FC<TripDetailsProps> = ({ 
  route, 
  origin, 
  destination, 
  onBack, 
  onComplete 
}) => {
  const { user } = useAuth();
  const { saveIncompleteTrip, completeTrip, incompleteTrip } = useTrip();
  
  // Initialize state from incomplete trip if available
  const [teamSize, setTeamSize] = useState(incompleteTrip?.teamSize || 1);
  const [teamName, setTeamName] = useState(incompleteTrip?.teamName || '');
  const [tripTagline, setTripTagline] = useState(incompleteTrip?.tripTagline || '');
  const [coTravellers, setCoTravellers] = useState<CoTraveller[]>(
    incompleteTrip?.coTravellers || []
  );
  const [images, setImages] = useState<string[]>(incompleteTrip?.images || []);
  const [addingCoTravellers, setAddingCoTravellers] = useState(teamSize > 1);

  const teamSizeOptions = [
    { value: 1, label: 'Solo', description: 'Just me' },
    { value: 2, label: 'Duo', description: '2 people' },
    { value: 4, label: 'Squad', description: '4 people' },
    { value: 0, label: 'Custom', description: 'Specify number' },
  ];

  const handleTeamSizeChange = (size: number) => {
    setTeamSize(size);
    if (size > 1) {
      setAddingCoTravellers(true);
      // Add empty co-travellers if needed
      const needed = size - 1 - coTravellers.length;
      if (needed > 0) {
        const newTravellers = Array(needed).fill(null).map(() => ({
          fullName: '',
          dateOfBirth: '',
          age: undefined,
          gender: '',
          relationship: '',
          contact: '',
        }));
        setCoTravellers([...coTravellers, ...newTravellers]);
      }
    } else {
      setAddingCoTravellers(false);
      setCoTravellers([]);
    }
  };

  const handleCustomTeamSize = (size: number) => {
    if (size > 0 && size <= 20) {
      handleTeamSizeChange(size);
    }
  };

  const addCoTraveller = () => {
    setCoTravellers([...coTravellers, {
      fullName: '',
      dateOfBirth: '',
      age: undefined,
      gender: '',
      relationship: '',
      contact: '',
    }]);
  };

  const removeCoTraveller = (index: number) => {
    setCoTravellers(coTravellers.filter((_, i) => i !== index));
  };

  const updateCoTraveller = (index: number, field: string, value: any) => {
    const updated = [...coTravellers];
    updated[index] = { ...updated[index], [field]: value };
    
    // Auto-calculate age from date of birth
    if (field === 'dateOfBirth' && value) {
      const age = new Date().getFullYear() - new Date(value).getFullYear();
      updated[index].age = age;
    }
    
    setCoTravellers(updated);
  };

  const handleImageUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const files = event.target.files;
    if (!files) return;

    Array.from(files).forEach(file => {
      if (file.size > 2 * 1024 * 1024) { // 2MB limit
        toast({
          title: "File too large",
          description: `${file.name} is larger than 2MB`,
          variant: "destructive",
        });
        return;
      }

      const reader = new FileReader();
      reader.onload = (e) => {
        const base64 = e.target?.result as string;
        setImages(prev => [...prev, base64]);
      };
      reader.readAsDataURL(file);
    });
  };

  const removeImage = (index: number) => {
    setImages(images.filter((_, i) => i !== index));
  };

  const handleSaveIncomplete = () => {
    const tripData = {
      userId: user?.id,
      origin,
      destination,
      selectedRoute: route,
      teamSize,
      teamName,
      tripTagline,
      coTravellers: coTravellers.filter(ct => ct.fullName.trim()),
      images,
    };

    saveIncompleteTrip(tripData);
    toast({
      title: "Trip saved",
      description: "Your progress has been saved. You can resume anytime!",
    });
    onComplete();
  };

  const handleCompleteTrip = () => {
    // Validation
    if (teamSize > 1 && addingCoTravellers) {
      const validTravellers = coTravellers.filter(ct => ct.fullName.trim());
      if (validTravellers.length < teamSize - 1) {
        toast({
          title: "Missing co-traveller details",
          description: "Please add details for all team members or disable adding co-travellers",
          variant: "destructive",
        });
        return;
      }
    }

    const tripData = {
      id: incompleteTrip?.id || Date.now().toString(),
      userId: user?.id || '',
      origin,
      destination,
      selectedRoute: route,
      teamSize,
      teamName,
      tripTagline,
      coTravellers: coTravellers.filter(ct => ct.fullName.trim()),
      images,
      status: 'completed' as const,
      createdAt: incompleteTrip?.createdAt || new Date().toISOString(),
    };

    completeTrip(tripData);
    toast({
      title: "Trip completed! 🎉",
      description: "Your journey has been saved. Don't forget to add a review!",
    });
    onComplete();
  };

  return (
    <div className="space-y-6 animate-slide-up">
      {/* Header */}
      <div className="flex items-center gap-4">
        <Button variant="ghost" size="sm" onClick={onBack} className="hover:bg-primary/10">
          <ArrowLeft className="h-4 w-4 mr-2" />
          Back to Results
        </Button>
      </div>

      <div>
        <h2 className="text-2xl font-bold bg-gradient-travel bg-clip-text text-transparent mb-2">
          Trip Details & Team
        </h2>
        <p className="text-muted-foreground">
          Complete your trip planning with team details and preferences
        </p>
      </div>

      {/* Selected Route Summary */}
      <Card className="border-primary/20 bg-primary/5">
        <CardContent className="pt-4">
          <div className="flex items-center justify-between">
            <div>
              <p className="font-semibold">{origin} → {destination}</p>
              <p className="text-sm text-muted-foreground">
                via {route.mode} • {route.distance}km • {Math.floor(route.duration / 60)}h {route.duration % 60}m • ₹{route.cost}
              </p>
            </div>
            <Badge className="bg-travel-green text-white">Selected</Badge>
          </div>
        </CardContent>
      </Card>

      {/* Team Size Selection */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Users className="h-5 w-5" />
            Team Size
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
            {teamSizeOptions.map((option) => (
              <Button
                key={option.label}
                variant={teamSize === option.value ? "default" : "outline"}
                className="h-auto p-4 flex flex-col"
                onClick={() => option.value === 0 ? null : handleTeamSizeChange(option.value)}
              >
                <span className="font-semibold">{option.label}</span>
                <span className="text-xs text-muted-foreground">{option.description}</span>
              </Button>
            ))}
          </div>

          {teamSize === 0 && (
            <div className="space-y-2">
              <Label>Custom team size</Label>
              <Input
                type="number"
                min="1"
                max="20"
                placeholder="Enter number of people"
                onChange={(e) => handleCustomTeamSize(parseInt(e.target.value) || 1)}
              />
            </div>
          )}
        </CardContent>
      </Card>

      {/* Trip Details */}
      <Card>
        <CardHeader>
          <CardTitle>Trip Details (Optional)</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="teamName">Team Name</Label>
            <Input
              id="teamName"
              placeholder="Give your travel group a fun name"
              value={teamName}
              onChange={(e) => setTeamName(e.target.value)}
            />
          </div>
          <div className="space-y-2">
            <Label htmlFor="tripTagline">Trip Tagline</Label>
            <Input
              id="tripTagline"
              placeholder="A memorable phrase for your journey"
              value={tripTagline}
              onChange={(e) => setTripTagline(e.target.value)}
            />
          </div>
        </CardContent>
      </Card>

      {/* Co-Travellers */}
      {teamSize > 1 && (
        <Card>
          <CardHeader>
            <div className="flex items-center justify-between">
              <CardTitle>Co-Travellers ({teamSize - 1} needed)</CardTitle>
              <div className="flex items-center gap-2">
                <Label htmlFor="add-travellers" className="text-sm">Add details now</Label>
                <input
                  id="add-travellers"
                  type="checkbox"
                  checked={addingCoTravellers}
                  onChange={(e) => setAddingCoTravellers(e.target.checked)}
                  className="rounded"
                />
              </div>
            </div>
          </CardHeader>
          {addingCoTravellers && (
            <CardContent className="space-y-4">
              {coTravellers.map((traveller, index) => (
                <div key={index} className="border rounded-lg p-4 space-y-3">
                  <div className="flex items-center justify-between">
                    <h4 className="font-medium">Co-Traveller {index + 1}</h4>
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => removeCoTraveller(index)}
                    >
                      <X className="h-4 w-4" />
                    </Button>
                  </div>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                    <div>
                      <Label className="text-xs">Full Name *</Label>
                      <Input
                        placeholder="Enter full name"
                        value={traveller.fullName}
                        onChange={(e) => updateCoTraveller(index, 'fullName', e.target.value)}
                      />
                    </div>
                    <div>
                      <Label className="text-xs">Date of Birth</Label>
                      <Input
                        type="date"
                        value={traveller.dateOfBirth}
                        onChange={(e) => updateCoTraveller(index, 'dateOfBirth', e.target.value)}
                      />
                    </div>
                    <div>
                      <Label className="text-xs">Gender</Label>
                      <Input
                        placeholder="Gender"
                        value={traveller.gender}
                        onChange={(e) => updateCoTraveller(index, 'gender', e.target.value)}
                      />
                    </div>
                    <div>
                      <Label className="text-xs">Relationship</Label>
                      <Input
                        placeholder="Friend, Family, etc."
                        value={traveller.relationship}
                        onChange={(e) => updateCoTraveller(index, 'relationship', e.target.value)}
                      />
                    </div>
                  </div>
                </div>
              ))}
              
              {coTravellers.length < teamSize - 1 && (
                <Button variant="outline" onClick={addCoTraveller}>
                  <Plus className="h-4 w-4 mr-2" />
                  Add Co-Traveller
                </Button>
              )}
            </CardContent>
          )}
        </Card>
      )}

      {/* Photo Upload */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Camera className="h-5 w-5" />
            Trip Photos (Optional)
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="border-2 border-dashed border-muted rounded-lg p-6 text-center">
            <input
              type="file"
              multiple
              accept="image/*"
              onChange={handleImageUpload}
              className="hidden"
              id="photo-upload"
            />
            <label htmlFor="photo-upload" className="cursor-pointer">
              <Camera className="h-8 w-8 text-muted-foreground mx-auto mb-2" />
              <p className="text-sm text-muted-foreground">
                Click to upload photos (up to 6 images, 2MB each)
              </p>
            </label>
          </div>

          {images.length > 0 && (
            <div className="grid grid-cols-3 gap-3">
              {images.map((image, index) => (
                <div key={index} className="relative">
                  <img
                    src={image}
                    alt={`Trip photo ${index + 1}`}
                    className="w-full h-24 object-cover rounded-lg"
                  />
                  <Button
                    variant="destructive"
                    size="sm"
                    className="absolute -top-2 -right-2 h-6 w-6 p-0"
                    onClick={() => removeImage(index)}
                  >
                    <X className="h-3 w-3" />
                  </Button>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>

      {/* Action Buttons */}
      <div className="flex gap-3">
        <Button
          variant="outline"
          onClick={handleSaveIncomplete}
          className="flex-1"
        >
          <Save className="h-4 w-4 mr-2" />
          Save as Incomplete
        </Button>
        <Button
          onClick={handleCompleteTrip}
          className="flex-1 bg-gradient-button hover:shadow-travel"
        >
          <Check className="h-4 w-4 mr-2" />
          Complete Trip
        </Button>
      </div>
    </div>
  );
};

export default TripDetails;