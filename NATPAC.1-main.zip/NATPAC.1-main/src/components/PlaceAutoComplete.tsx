import { useState, useEffect, useRef } from 'react';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Button } from '@/components/ui/button';
import { MapPin, Navigation2, Loader2, AlertCircle } from 'lucide-react';
import { Badge } from '@/components/ui/badge';
import { getCurrentLocation, geocodeLocation, validatePlace, getPlaceSuggestions } from '@/lib/googleMaps';
import { toast } from '@/hooks/use-toast';

interface PlaceAutoCompleteProps {
  label: string;
  placeholder: string;
  value: string;
  onChange: (value: string) => void;
  icon?: React.ReactNode;
  allowCurrentLocation?: boolean;
}

const PlaceAutoComplete: React.FC<PlaceAutoCompleteProps> = ({
  label,
  placeholder,
  value,
  onChange,
  icon,
  allowCurrentLocation = false
}) => {
  const [suggestions, setSuggestions] = useState<string[]>([]);
  const [loading, setLoading] = useState(false);
  const [locationLoading, setLocationLoading] = useState(false);
  const [showSuggestions, setShowSuggestions] = useState(false);
  const [validationStatus, setValidationStatus] = useState<'valid' | 'invalid' | 'pending' | null>(null);
  const [validationSuggestions, setValidationSuggestions] = useState<string[]>([]);
  const inputRef = useRef<HTMLInputElement>(null);
  const debounceRef = useRef<NodeJS.Timeout>();

  useEffect(() => {
    if (debounceRef.current) {
      clearTimeout(debounceRef.current);
    }

    if (value.length >= 2) {
      debounceRef.current = setTimeout(async () => {
        setLoading(true);
        try {
          const placeSuggestions = await getPlaceSuggestions(value);
          setSuggestions(placeSuggestions);
          setShowSuggestions(true);
        } catch (error) {
          console.error('Error fetching suggestions:', error);
        } finally {
          setLoading(false);
        }
      }, 300);
    } else {
      setSuggestions([]);
      setShowSuggestions(false);
    }

    return () => {
      if (debounceRef.current) {
        clearTimeout(debounceRef.current);
      }
    };
  }, [value]);

  const handleCurrentLocation = async () => {
    setLocationLoading(true);
    try {
      const position = await getCurrentLocation();
      const address = await geocodeLocation(position.coords.latitude, position.coords.longitude);
      onChange(address);
      toast({
        title: "Location detected",
        description: `Current location: ${address}`,
      });
    } catch (error) {
      toast({
        title: "Location error",
        description: "Unable to detect your current location. Please enter manually.",
        variant: "destructive",
      });
    } finally {
      setLocationLoading(false);
    }
  };

  const handleSuggestionClick = (suggestion: string) => {
    onChange(suggestion);
    setShowSuggestions(false);
    setSuggestions([]);
  };

  const handleValidationSuggestionClick = (suggestion: string) => {
    onChange(suggestion);
    setValidationStatus(null);
    setValidationSuggestions([]);
  };

  const validateCurrentPlace = async () => {
    if (!value.trim()) return;

    setValidationStatus('pending');
    try {
      const validation = await validatePlace(value);
      if (validation.valid) {
        setValidationStatus('valid');
        setValidationSuggestions([]);
      } else {
        setValidationStatus('invalid');
        setValidationSuggestions(validation.suggestions || []);
      }
    } catch (error) {
      setValidationStatus('invalid');
      setValidationSuggestions([]);
    }
  };

  const handleBlur = () => {
    // Delay hiding suggestions to allow clicks
    setTimeout(() => {
      setShowSuggestions(false);
      if (value.trim()) {
        validateCurrentPlace();
      }
    }, 200);
  };

  return (
    <div className="space-y-2 relative">
      <Label htmlFor={label} className="flex items-center gap-2">
        {icon}
        {label}
      </Label>
      <div className="flex gap-2">
        <div className="flex-1 relative">
          <Input
            ref={inputRef}
            id={label}
            placeholder={placeholder}
            value={value}
            onChange={(e) => onChange(e.target.value)}
            onBlur={handleBlur}
            onFocus={() => suggestions.length > 0 && setShowSuggestions(true)}
            className={`transition-all duration-200 focus:shadow-card-hover ${
              validationStatus === 'valid' ? 'border-green-500' :
              validationStatus === 'invalid' ? 'border-red-500' : ''
            }`}
          />
          
          {/* Validation Status Icons */}
          {validationStatus === 'pending' && (
            <div className="absolute right-3 top-1/2 transform -translate-y-1/2">
              <Loader2 className="h-4 w-4 animate-spin text-muted-foreground" />
            </div>
          )}
          {validationStatus === 'valid' && (
            <div className="absolute right-3 top-1/2 transform -translate-y-1/2">
              <div className="h-2 w-2 bg-green-500 rounded-full" />
            </div>
          )}
          {validationStatus === 'invalid' && (
            <div className="absolute right-3 top-1/2 transform -translate-y-1/2">
              <AlertCircle className="h-4 w-4 text-red-500" />
            </div>
          )}

          {/* Auto-complete suggestions */}
          {showSuggestions && suggestions.length > 0 && (
            <div className="absolute top-full left-0 right-0 z-10 mt-1 bg-background border rounded-md shadow-lg max-h-48 overflow-y-auto">
              {suggestions.map((suggestion, index) => (
                <button
                  key={index}
                  className="w-full text-left px-4 py-2 hover:bg-muted transition-colors text-sm"
                  onClick={() => handleSuggestionClick(suggestion)}
                >
                  <div className="flex items-center gap-2">
                    <MapPin className="h-3 w-3 text-muted-foreground" />
                    {suggestion}
                  </div>
                </button>
              ))}
            </div>
          )}
        </div>

        {allowCurrentLocation && (
          <Button
            type="button"
            variant="outline"
            size="sm"
            onClick={handleCurrentLocation}
            disabled={locationLoading}
            className="px-3"
          >
            {locationLoading ? (
              <Loader2 className="h-4 w-4 animate-spin" />
            ) : (
              <Navigation2 className="h-4 w-4" />
            )}
          </Button>
        )}
      </div>

      {/* Validation Error */}
      {validationStatus === 'invalid' && (
        <div className="space-y-2">
          <div className="flex items-center gap-2 text-red-600 text-sm">
            <AlertCircle className="h-3 w-3" />
            <span>
              Oops! The place '{value}' isn't in Google Maps 🚫. Please try again with a valid city.
            </span>
          </div>
          
          {validationSuggestions.length > 0 && (
            <div>
              <p className="text-sm text-muted-foreground mb-2">Did you mean:</p>
              <div className="flex flex-wrap gap-2">
                {validationSuggestions.map((suggestion, index) => (
                  <Badge
                    key={index}
                    variant="outline"
                    className="cursor-pointer hover:bg-primary/10"
                    onClick={() => handleValidationSuggestionClick(suggestion)}
                  >
                    {suggestion}
                  </Badge>
                ))}
              </div>
            </div>
          )}
        </div>
      )}

      {loading && (
        <div className="text-xs text-muted-foreground">
          Loading suggestions...
        </div>
      )}
    </div>
  );
};

export default PlaceAutoComplete;