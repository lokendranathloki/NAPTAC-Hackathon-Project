import { useState } from 'react';
import { useAuth } from '@/contexts/AuthContext';
import { useTrip } from '@/contexts/TripContext';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group';
import { Checkbox } from '@/components/ui/checkbox';
import { Star, Send } from 'lucide-react';
import { toast } from '@/hooks/use-toast';

interface TripReviewModalProps {
  trip: any;
  open: boolean;
  onClose: () => void;
}

const TripReviewModal: React.FC<TripReviewModalProps> = ({ trip, open, onClose }) => {
  const { user } = useAuth();
  const { addReview } = useTrip();
  
  const [formData, setFormData] = useState({
    roadCondition: '',
    trafficCongestion: '',
    safety: '',
    publicTransport: '',
    travelCost: '',
    pedestrianFacility: '',
    delays: '',
    satisfaction: '',
    improvements: [] as string[],
    additionalSuggestions: '',
  });

  const [currentStep, setCurrentStep] = useState(0);
  const [submitting, setSubmitting] = useState(false);

  const questions = [
    {
      id: 'roadCondition',
      question: 'How would you rate the road condition during your trip?',
      options: ['Very Good', 'Good', 'Average', 'Poor', 'Very Poor']
    },
    {
      id: 'trafficCongestion',
      question: 'How was the traffic congestion on your route?',
      options: ['Very High', 'High', 'Moderate', 'Low', 'Very Low']
    },
    {
      id: 'safety',
      question: 'How safe did you feel while traveling?',
      options: ['Very Safe', 'Safe', 'Neutral', 'Unsafe', 'Very Unsafe']
    },
    {
      id: 'publicTransport',
      question: 'Was public transport available and convenient (if used)?',
      options: ['Always Available & Convenient', 'Often Available', 'Sometimes Available', 'Rarely Available', 'Not Available']
    },
    {
      id: 'travelCost',
      question: 'How would you rate the travel cost for this trip?',
      options: ['Very Affordable', 'Affordable', 'Neutral', 'Expensive', 'Very Expensive']
    },
    {
      id: 'pedestrianFacility',
      question: 'Was there proper pedestrian and cycling facility on your route?',
      options: ['Yes, Well Maintained', 'Available but Poor Condition', 'Not Available']
    },
    {
      id: 'delays',
      question: 'Did you face any delays during the trip?',
      options: ['Yes – due to traffic', 'Yes – due to road work', 'Yes – due to vehicle issues', 'No delays']
    },
    {
      id: 'satisfaction',
      question: 'Overall, how satisfied are you with your trip experience?',
      options: ['Very Satisfied', 'Satisfied', 'Neutral', 'Dissatisfied', 'Very Dissatisfied']
    }
  ];

  const improvementOptions = [
    'Better road maintenance',
    'Reduced traffic congestion',
    'More frequent and reliable public transport',
    'Lower travel costs / affordable options',
    'Better safety measures (lighting, policing, signals)',
    'Improved pedestrian facilities (sidewalks, crossings)',
    'Better cycling infrastructure (lanes, parking)',
  ];

  const handleRadioChange = (questionId: string, value: string) => {
    setFormData(prev => ({ ...prev, [questionId]: value }));
  };

  const handleCheckboxChange = (improvement: string, checked: boolean) => {
    setFormData(prev => ({
      ...prev,
      improvements: checked
        ? [...prev.improvements, improvement]
        : prev.improvements.filter(item => item !== improvement)
    }));
  };

  const handleNext = () => {
    const currentQuestion = questions[currentStep];
    if (!formData[currentQuestion.id as keyof typeof formData]) {
      toast({
        title: "Please select an option",
        description: "This question is required",
        variant: "destructive",
      });
      return;
    }
    
    if (currentStep < questions.length - 1) {
      setCurrentStep(currentStep + 1);
    } else {
      setCurrentStep(questions.length); // Move to improvements section
    }
  };

  const handleBack = () => {
    if (currentStep > 0) {
      setCurrentStep(currentStep - 1);
    }
  };

  const handleSubmit = async () => {
    if (formData.improvements.length === 0) {
      toast({
        title: "Please select improvements",
        description: "You must select at least one improvement suggestion",
        variant: "destructive",
      });
      return;
    }

    setSubmitting(true);

    const reviewData = {
      userId: user?.id || '',
      username: user?.username || '',
      tripId: trip.id,
      rating: 5, // Default rating
      ...formData,
    };

    try {
      addReview(reviewData);

      toast({
        title: "Review submitted! 🎉",
        description: "Thank you for your feedback! You earned 10 points.",
      });

      // Add some celebratory animation
      setTimeout(() => {
        onClose();
      }, 1500);
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to submit review. Please try again.",
        variant: "destructive",
      });
    } finally {
      setSubmitting(false);
    }
  };

  if (!trip) return null;

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Star className="h-5 w-5 text-yellow-500" />
            Review Your Trip
          </DialogTitle>
          <DialogDescription>
            Share your experience: {trip.origin} → {trip.destination}
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-6">
          {/* Progress Bar */}
          <div className="w-full bg-muted rounded-full h-2">
            <div 
              className="bg-gradient-travel h-2 rounded-full transition-all duration-300"
              style={{ 
                width: `${((currentStep + 1) / (questions.length + 2)) * 100}%` 
              }}
            />
          </div>

          {/* Questions */}
          {currentStep < questions.length && (
            <div className="space-y-4 animate-fade-in">
              <div>
                <h3 className="text-lg font-semibold mb-2">
                  Question {currentStep + 1} of {questions.length}
                </h3>
                <p className="text-muted-foreground">
                  {questions[currentStep].question}
                </p>
              </div>

              <RadioGroup 
                value={formData[questions[currentStep].id as keyof typeof formData] as string}
                onValueChange={(value) => handleRadioChange(questions[currentStep].id, value)}
                className="space-y-3"
              >
                {questions[currentStep].options.map((option) => (
                  <div key={option} className="flex items-center space-x-2">
                    <RadioGroupItem 
                      value={option} 
                      id={option}
                      className="text-primary"
                    />
                    <Label htmlFor={option} className="cursor-pointer">
                      {option}
                    </Label>
                  </div>
                ))}
              </RadioGroup>

              <div className="flex justify-between pt-4">
                <Button 
                  variant="outline" 
                  onClick={handleBack}
                  disabled={currentStep === 0}
                >
                  Back
                </Button>
                <Button onClick={handleNext}>
                  {currentStep === questions.length - 1 ? 'Continue' : 'Next'}
                </Button>
              </div>
            </div>
          )}

          {/* Improvements Section */}
          {currentStep === questions.length && (
            <div className="space-y-4 animate-fade-in">
              <div>
                <h3 className="text-lg font-semibold mb-2">
                  What improvements would make your travel experience better?
                </h3>
                <p className="text-muted-foreground">
                  Select all that apply (required)
                </p>
              </div>

              <div className="space-y-3">
                {improvementOptions.map((improvement) => (
                  <div key={improvement} className="flex items-center space-x-2">
                    <Checkbox
                      id={improvement}
                      checked={formData.improvements.includes(improvement)}
                      onCheckedChange={(checked) => 
                        handleCheckboxChange(improvement, checked as boolean)
                      }
                    />
                    <Label htmlFor={improvement} className="cursor-pointer text-sm">
                      {improvement}
                    </Label>
                  </div>
                ))}
              </div>

              <div className="flex justify-between pt-4">
                <Button variant="outline" onClick={handleBack}>
                  Back
                </Button>
                <Button 
                  onClick={() => setCurrentStep(currentStep + 1)}
                  disabled={formData.improvements.length === 0}
                >
                  Continue
                </Button>
              </div>
            </div>
          )}

          {/* Additional Suggestions */}
          {currentStep === questions.length + 1 && (
            <div className="space-y-4 animate-fade-in">
              <div>
                <h3 className="text-lg font-semibold mb-2">
                  Any additional suggestions?
                </h3>
                <p className="text-muted-foreground">
                  Share any other thoughts or tips for future travelers (optional)
                </p>
              </div>

              <Textarea
                placeholder="Your additional suggestions..."
                value={formData.additionalSuggestions}
                onChange={(e) => setFormData(prev => ({ 
                  ...prev, 
                  additionalSuggestions: e.target.value 
                }))}
                rows={4}
              />

              <div className="flex justify-between pt-4">
                <Button variant="outline" onClick={handleBack}>
                  Back
                </Button>
                <Button 
                  onClick={handleSubmit}
                  disabled={submitting}
                  className="bg-gradient-button hover:shadow-travel"
                >
                  {submitting ? (
                    <>
                      <Star className="h-4 w-4 mr-2 animate-spin" />
                      Submitting...
                    </>
                  ) : (
                    <>
                      <Send className="h-4 w-4 mr-2" />
                      Submit Review
                    </>
                  )}
                </Button>
              </div>
            </div>
          )}
        </div>
      </DialogContent>
    </Dialog>
  );
};

export default TripReviewModal;