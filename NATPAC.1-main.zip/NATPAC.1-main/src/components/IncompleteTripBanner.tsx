import { useTrip } from '@/contexts/TripContext';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { AlertTriangle, ArrowRight, X } from 'lucide-react';
import { toast } from '@/hooks/use-toast';

const IncompleteTripBanner = () => {
  const { incompleteTrip, discardIncompleteTrip } = useTrip();

  if (!incompleteTrip) return null;

  const handleResume = () => {
    // Emit custom event that Dashboard can listen to
    window.dispatchEvent(new CustomEvent('resumeIncompleteTrip', { 
      detail: incompleteTrip 
    }));
    
    toast({
      title: "Resuming trip",
      description: "Loading your saved progress...",
    });
  };

  const handleDiscard = () => {
    discardIncompleteTrip();
    toast({
      title: "Trip discarded",
      description: "Your incomplete trip has been removed.",
    });
  };

  return (
    <Card className="mb-6 border-travel-orange/20 bg-travel-orange/5 animate-fade-in">
      <CardContent className="pt-4">
        <div className="flex items-start gap-3">
          <AlertTriangle className="h-5 w-5 text-travel-orange mt-0.5" />
          <div className="flex-1">
            <h3 className="font-semibold text-travel-orange mb-1">
              You have an incomplete trip
            </h3>
            <p className="text-sm text-muted-foreground mb-3">
              {incompleteTrip.origin} → {incompleteTrip.destination}
              {incompleteTrip.teamSize > 1 && ` • ${incompleteTrip.teamSize} travelers`}
              {incompleteTrip.createdAt && ` • Started ${new Date(incompleteTrip.createdAt).toLocaleDateString()}`}
            </p>
            <div className="flex items-center gap-2">
              <Button 
                size="sm" 
                onClick={handleResume}
                className="bg-travel-orange hover:bg-travel-orange/90"
              >
                <ArrowRight className="h-3 w-3 mr-1" />
                Resume Trip
              </Button>
              <Button 
                variant="outline" 
                size="sm" 
                onClick={handleDiscard}
                className="border-travel-orange/20 text-travel-orange hover:bg-travel-orange/10"
              >
                <X className="h-3 w-3 mr-1" />
                Discard
              </Button>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
};

export default IncompleteTripBanner;