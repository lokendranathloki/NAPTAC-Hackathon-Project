import React from 'react';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Shield, Eye, Database, Users } from 'lucide-react';

interface ConsentModalProps {
  open: boolean;
  onAccept: () => void;
  onDecline: () => void;
}

const ConsentModal: React.FC<ConsentModalProps> = ({ open, onAccept, onDecline }) => {
  return (
    <Dialog open={open} onOpenChange={(isOpen) => !isOpen && onDecline()}>
      <DialogContent className="max-w-md">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Shield className="h-5 w-5 text-primary" />
            Data Collection Consent
          </DialogTitle>
          <DialogDescription className="text-left space-y-4">
            <p>
              Welcome to NATPAC Travel! To provide you with the best travel planning experience, 
              we need your consent to collect and use the following data:
            </p>
            
            <div className="space-y-3">
              <div className="flex items-start gap-3">
                <Users className="h-4 w-4 text-primary mt-0.5" />
                <div>
                  <p className="font-medium text-sm">Trip Information</p>
                  <p className="text-xs text-muted-foreground">
                    Origin, destination, travel mode, and co-traveler details
                  </p>
                </div>
              </div>
              
              <div className="flex items-start gap-3">
                <Eye className="h-4 w-4 text-primary mt-0.5" />
                <div>
                  <p className="font-medium text-sm">Reviews & Feedback</p>
                  <p className="text-xs text-muted-foreground">
                    Your travel reviews to help improve services for others
                  </p>
                </div>
              </div>
              
              <div className="flex items-start gap-3">
                <Database className="h-4 w-4 text-primary mt-0.5" />
                <div>
                  <p className="font-medium text-sm">Usage Analytics</p>
                  <p className="text-xs text-muted-foreground">
                    App usage patterns to enhance user experience
                  </p>
                </div>
              </div>
            </div>
            
            <p className="text-xs text-muted-foreground border-t pt-3">
              Your data is stored locally on your device for this demo. 
              In a production app, data would be encrypted and stored securely 
              according to privacy regulations.
            </p>
          </DialogDescription>
        </DialogHeader>
        <DialogFooter className="flex-col space-y-2">
          <Button onClick={onAccept} className="w-full">
            Accept & Continue
          </Button>
          <Button variant="outline" onClick={onDecline} className="w-full">
            Decline
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
};

export default ConsentModal;