import React, { createContext, useContext, useState, useEffect } from 'react';

const languages = {
  en: {
    // Common
    save: 'Save',
    cancel: 'Cancel',
    back: 'Back',
    next: 'Next',
    submit: 'Submit',
    edit: 'Edit',
    delete: 'Delete',
    search: 'Search',
    loading: 'Loading...',
    
    // Navigation
    dashboard: 'Dashboard',
    tripHistory: 'Trip History',
    settings: 'Settings',
    notifications: 'Notifications',
    help: 'Help & Support',
    logout: 'Logout',
    leaderboard: 'Leaderboard',
    festivalTourism: 'Festival & Tourism',
    
    // Trip Planning
    planTrip: 'Plan Trip',
    from: 'From',
    to: 'To',
    selectRoute: 'Select Route',
    viewOnMap: 'View on Map',
    distance: 'Distance',
    duration: 'Duration',
    cost: 'Cost',
    mode: 'Mode',
    
    // Profile
    profile: 'Profile',
    username: 'Username',
    email: 'Email',
    fullName: 'Full Name',
    phone: 'Phone',
    editProfile: 'Edit Profile',
    profilePicture: 'Profile Picture',
    
    // Settings
    language: 'Language',
    darkMode: 'Dark Mode',
    lightMode: 'Light Mode',
    favorites: 'Favorites',
    about: 'About',
    deleteAccount: 'Delete Account',
  },
  hi: {
    // Common
    save: 'सेव करें',
    cancel: 'रद्द करें',
    back: 'वापस',
    next: 'आगे',
    submit: 'जमा करें',
    edit: 'संपादित करें',
    delete: 'हटाएं',
    search: 'खोजें',
    loading: 'लोड हो रहा है...',
    
    // Navigation
    dashboard: 'डैशबोर्ड',
    tripHistory: 'यात्रा इतिहास',
    settings: 'सेटिंग्स',
    notifications: 'सूचनाएं',
    help: 'सहायता और समर्थन',
    logout: 'लॉगआउट',
    leaderboard: 'लीडरबोर्ड',
    festivalTourism: 'त्योहार और पर्यटन',
    
    // Trip Planning
    planTrip: 'यात्रा की योजना बनाएं',
    from: 'से',
    to: 'तक',
    selectRoute: 'मार्ग चुनें',
    viewOnMap: 'मानचित्र पर देखें',
    distance: 'दूरी',
    duration: 'अवधि',
    cost: 'लागत',
    mode: 'साधन',
    
    // Profile
    profile: 'प्रोफ़ाइल',
    username: 'उपयोगकर्ता नाम',
    email: 'ईमेल',
    fullName: 'पूरा नाम',
    phone: 'फोन',
    editProfile: 'प्रोफ़ाइल संपादित करें',
    profilePicture: 'प्रोफ़ाइल चित्र',
    
    // Settings
    language: 'भाषा',
    darkMode: 'डार्क मोड',
    lightMode: 'लाइट मोड',
    favorites: 'पसंदीदा',
    about: 'के बारे में',
    deleteAccount: 'खाता हटाएं',
  },
  ta: {
    // Common
    save: 'சேமிக்கவும்',
    cancel: 'ரத்து செய்யவும்',
    back: 'பின்',
    next: 'அடுத்து',
    submit: 'சமர்ப்பிக்கவும்',
    edit: 'திருத்தவும்',
    delete: 'நீக்கவும்',
    search: 'தேடவும்',
    loading: 'ஏற்றுகிறது...',
    
    // Navigation
    dashboard: 'டாஷ்போர்டு',
    tripHistory: 'பயண வரலாறு',
    settings: 'அமைப்புகள்',
    notifications: 'அறிவிப்புகள்',
    help: 'உதவி மற்றும் ஆதரவு',
    logout: 'வெளியேறு',
    leaderboard: 'லீடர்போர்டு',
    festivalTourism: 'திருவிழா மற்றும் சுற்றுலா',
    
    // Trip Planning
    planTrip: 'பயணத் திட்டமிடவும்',
    from: 'இருந்து',
    to: 'வரை',
    selectRoute: 'பாதையைத் தேர்ந்தெடுக்கவும்',
    viewOnMap: 'வரைபடத்தில் பார்க்கவும்',
    distance: 'தூரம்',
    duration: 'கால அளவு',
    cost: 'செலவு',
    mode: 'வழி',
    
    // Profile
    profile: 'சுயவிவரம்',
    username: 'பயனர்பெயர்',
    email: 'மின்னஞ்சல்',
    fullName: 'முழு பெயர்',
    phone: 'தொலைபேசி',
    editProfile: 'சுயவிவரத்தைத் திருத்தவும்',
    profilePicture: 'சுயவிவர படம்',
    
    // Settings
    language: 'மொழி',
    darkMode: 'இருண்ட பயன்முறை',
    lightMode: 'ஒளி பயன்முறை',
    favorites: 'விருப்பங்கள்',
    about: 'பற்றி',
    deleteAccount: 'கணக்கை நீக்கவும்',
  },
  ml: {
    // Common
    save: 'സേവ് ചെയ്യുക',
    cancel: 'റദ്ദാക്കുക',
    back: 'പിന്നോട്ട്',
    next: 'അടുത്തത്',
    submit: 'സമർപ്പിക്കുക',
    edit: 'എഡിറ്റ് ചെയ്യുക',
    delete: 'ഇല്ലാതാക്കുക',
    search: 'തിരയുക',
    loading: 'ലോഡ് ചെയ്യുന്നു...',
    
    // Navigation
    dashboard: 'ഡാഷ്‌ബോർഡ്',
    tripHistory: 'യാത്രാ ചരിത്രം',
    settings: 'ക്രമീകരണങ്ങൾ',
    notifications: 'അറിയിപ്പുകൾ',
    help: 'സഹായവും പിന്തുണയും',
    logout: 'ലോഗൗട്ട്',
    leaderboard: 'ലീഡർബോർഡ്',
    festivalTourism: 'ഉത്സവവും വിനോദസഞ്ചാരവും',
    
    // Trip Planning
    planTrip: 'യാത്ര ആസൂത്രണം ചെയ്യുക',
    from: 'എവിടെ നിന്ന്',
    to: 'എവിടേക്ക്',
    selectRoute: 'റൂട്ട് തിരഞ്ഞെടുക്കുക',
    viewOnMap: 'മാപ്പിൽ കാണുക',
    distance: 'ദൂരം',
    duration: 'സമയം',
    cost: 'ചിലവ്',
    mode: 'മാർഗം',
    
    // Profile
    profile: 'പ്രൊഫൈൽ',
    username: 'യൂസർനേം',
    email: 'ഇമെയിൽ',
    fullName: 'പൂർണ്ണ നാമം',
    phone: 'ഫോൺ',
    editProfile: 'പ്രൊഫൈൽ എഡിറ്റ് ചെയ്യുക',
    profilePicture: 'പ്രൊഫൈൽ ചിത്രം',
    
    // Settings
    language: 'ഭാഷ',
    darkMode: 'ഡാർക്ക് മോഡ്',
    lightMode: 'ലൈറ്റ് മോഡ്',
    favorites: 'പ്രിയങ്കരങ്ങൾ',
    about: 'കുറിച്ച്',
    deleteAccount: 'അക്കൗണ്ട് ഇല്ലാതാക്കുക',
  },
  te: {
    // Common
    save: 'సేవ్ చేయండి',
    cancel: 'రద్దు చేయండి',
    back: 'వెనుకకు',
    next: 'తదుపరి',
    submit: 'సమర్పించండి',
    edit: 'సవరించండి',
    delete: 'తొలగించండి',
    search: 'వెతకండి',
    loading: 'లోడ్ అవుతోంది...',
    
    // Navigation
    dashboard: 'డాష్‌బోర్డ్',
    tripHistory: 'ప్రయాణ చరిత్ర',
    settings: 'సెట్టింగులు',
    notifications: 'నోటిఫికేషన్లు',
    help: 'సహాయం మరియు మద్దతు',
    logout: 'లాగ్‌అవుట్',
    leaderboard: 'లీడర్‌బోర్డ్',
    festivalTourism: 'పండుగలు మరియు పర్యటనలు',
    
    // Trip Planning
    planTrip: 'ప్రయాణం ప్లాన్ చేయండి',
    from: 'నుండి',
    to: 'వరకు',
    selectRoute: 'మార్గాన్ని ఎంచుకోండి',
    viewOnMap: 'మ్యాప్‌లో చూడండి',
    distance: 'దూరం',
    duration: 'వ్యవధి',
    cost: 'ఖర్చు',
    mode: 'మార్గం',
    
    // Profile
    profile: 'ప్రొఫైల్',
    username: 'యూజర్‌నేమ్',
    email: 'ఇమెయిల్',
    fullName: 'పూర్తి పేరు',
    phone: 'ఫోన్',
    editProfile: 'ప్రొఫైల్ ఎడిట్ చేయండి',
    profilePicture: 'ప్రొఫైల్ చిత్రం',
    
    // Settings
    language: 'భాష',
    darkMode: 'డార్క్ మోడ్',
    lightMode: 'లైట్ మోడ్',
    favorites: 'ఇష్టమైనవి',
    about: 'గురించి',
    deleteAccount: 'ఖాతాను తొలగించండి',
  },
  kn: {
    // Common
    save: 'ಉಳಿಸು',
    cancel: 'ರದ್ದುಮಾಡು',
    back: 'ಹಿಂದೆ',
    next: 'ಮುಂದೆ',
    submit: 'ಸಲ್ಲಿಸು',
    edit: 'ಸಂಪಾದಿಸು',
    delete: 'ಅಳಿಸು',
    search: 'ಹುಡುಕು',
    loading: 'ಲೋಡ್ ಆಗುತ್ತಿದೆ...',
    
    // Navigation
    dashboard: 'ಡ್ಯಾಶ್‌ಬೋರ್ಡ್',
    tripHistory: 'ಪ್ರಯಾಣದ ಇತಿಹಾಸ',
    settings: 'ಸೆಟ್ಟಿಂಗ್‌ಗಳು',
    notifications: 'ಅಧಿಸೂಚನೆಗಳು',
    help: 'ಸಹಾಯ ಮತ್ತು ಬೆಂಬಲ',
    logout: 'ಲಾಗ್‌ಔಟ್',
    leaderboard: 'ಲೀಡರ್‌ಬೋರ್ಡ್',
    festivalTourism: 'ಹಬ್ಬಗಳು ಮತ್ತು ಪ್ರವಾಸೋದ್ಯಮ',
    
    // Trip Planning
    planTrip: 'ಪ್ರಯಾಣವನ್ನು ಯೋಜಿಸಿ',
    from: 'ಇಂದ',
    to: 'ಗೆ',
    selectRoute: 'ಮಾರ್ಗವನ್ನು ಆಯ್ಕೆಮಾಡಿ',
    viewOnMap: 'ನಕ್ಷೆಯಲ್ಲಿ ನೋಡಿ',
    distance: 'ದೂರ',
    duration: 'ಅವಧಿ',
    cost: 'ವೆಚ್ಚ',
    mode: 'ವಿಧಾನ',
    
    // Profile
    profile: 'ಪ್ರೊಫೈಲ್',
    username: 'ಬಳಕೆದಾರ ಹೆಸರು',
    email: 'ಇಮೇಲ್',
    fullName: 'ಪೂರ್ಣ ಹೆಸರು',
    phone: 'ಫೋನ್',
    editProfile: 'ಪ್ರೊಫೈಲ್ ಸಂಪಾದಿಸಿ',
    profilePicture: 'ಪ್ರೊಫೈಲ್ ಚಿತ್ರ',
    
    // Settings
    language: 'ಭಾಷೆ',
    darkMode: 'ಡಾರ್ಕ್ ಮೋಡ್',
    lightMode: 'ಲೈಟ್ ಮೋಡ್',
    favorites: 'ಮೆಚ್ಚಿನವುಗಳು',
    about: 'ಬಗ್ಗೆ',
    deleteAccount: 'ಖಾತೆಯನ್ನು ಅಳಿಸಿ',
  }
};

interface LanguageContextType {
  language: string;
  setLanguage: (lang: string) => void;
  t: (key: string) => string;
  availableLanguages: { code: string; name: string; nativeName: string }[];
}

const LanguageContext = createContext<LanguageContextType | undefined>(undefined);

export const useLanguage = () => {
  const context = useContext(LanguageContext);
  if (!context) {
    throw new Error('useLanguage must be used within a LanguageProvider');
  }
  return context;
};

export const LanguageProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [language, setLanguageState] = useState<string>('en');

  const availableLanguages = [
    { code: 'en', name: 'English', nativeName: 'English' },
    { code: 'hi', name: 'Hindi', nativeName: 'हिंदी' },
    { code: 'ta', name: 'Tamil', nativeName: 'தமிழ்' },
    { code: 'ml', name: 'Malayalam', nativeName: 'മലയാളം' },
    { code: 'te', name: 'Telugu', nativeName: 'తెలుగు' },
    { code: 'kn', name: 'Kannada', nativeName: 'ಕನ್ನಡ' },
  ];

  useEffect(() => {
    const savedLanguage = localStorage.getItem('travel_app_language');
    if (savedLanguage && languages[savedLanguage as keyof typeof languages]) {
      setLanguageState(savedLanguage);
    }
  }, []);

  const setLanguage = (lang: string) => {
    setLanguageState(lang);
    localStorage.setItem('travel_app_language', lang);
  };

  const t = (key: string): string => {
    const currentLanguage = languages[language as keyof typeof languages] || languages.en;
    return currentLanguage[key as keyof typeof currentLanguage] || key;
  };

  return (
    <LanguageContext.Provider
      value={{
        language,
        setLanguage,
        t,
        availableLanguages,
      }}
    >
      {children}
    </LanguageContext.Provider>
  );
};