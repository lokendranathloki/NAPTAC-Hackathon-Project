import React, { createContext, useContext, useState, useEffect } from 'react';

interface CoTraveller {
  fullName: string;
  dateOfBirth?: string;
  age?: number;
  gender?: string;
  relationship?: string;
  contact?: string;
}

interface TripRoute {
  id: string;
  mode: string;
  distance: number;
  duration: number;
  cost: number;
  coTravellers: string[];
}

interface Trip {
  id: string;
  userId: string;
  origin: string;
  destination: string;
  selectedRoute?: TripRoute;
  teamSize: number;
  teamName?: string;
  tripTagline?: string;
  coTravellers: CoTraveller[];
  images: string[];
  status: 'incomplete' | 'completed';
  createdAt: string;
  completedAt?: string;
  reviews?: TripReview[];
}

interface TripReview {
  id: string;
  userId: string;
  username: string;
  tripId: string;
  rating: number;
  roadCondition: string;
  trafficCongestion: string;
  safety: string;
  publicTransport: string;
  travelCost: string;
  pedestrianFacility: string;
  delays: string;
  satisfaction: string;
  improvements: string[];
  additionalSuggestions?: string;
  createdAt: string;
}

interface TripContextType {
  incompleteTrip: Trip | null;
  completedTrips: Trip[];
  saveIncompleteTrip: (trip: Partial<Trip>) => void;
  completeTrip: (trip: Trip) => void;
  discardIncompleteTrip: () => void;
  addReview: (review: Omit<TripReview, 'id' | 'createdAt'>) => void;
  getReviewsForRoute: (origin: string, destination: string) => TripReview[];
  generateRouteOptions: (origin: string, destination: string) => TripRoute[];
}

const TripContext = createContext<TripContextType | undefined>(undefined);

export const useTrip = () => {
  const context = useContext(TripContext);
  if (!context) {
    throw new Error('useTrip must be used within a TripProvider');
  }
  return context;
};

const TRANSPORT_MODES = [
  { mode: 'Walk', speed: 5, costPerKm: 0 },
  { mode: 'Bike', speed: 15, costPerKm: 0.5 },
  { mode: 'Bus', speed: 40, costPerKm: 2.5 },
  { mode: 'Train', speed: 60, costPerKm: 1.8 },
];

const SAMPLE_NAMES = [
  'Arjun Kumar', 'Priya Sharma', 'Rajesh Patel', 'Sneha Reddy', 'Vikram Singh',
  'Anita Gupta', 'Rohit Verma', 'Kavya Nair', 'Suresh Yadav', 'Meera Joshi',
  'Amit Das', 'Ritu Agarwal', 'Kiran Kumar', 'Deepika Rao', 'Sanjay Mishra'
];

export const TripProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [incompleteTrip, setIncompleteTrip] = useState<Trip | null>(null);
  const [completedTrips, setCompletedTrips] = useState<Trip[]>([]);

  useEffect(() => {
    // Load data from localStorage
    const incomplete = localStorage.getItem('travel_app_incomplete_trip');
    const completed = localStorage.getItem('travel_app_completed_trips');
    
    if (incomplete) {
      setIncompleteTrip(JSON.parse(incomplete));
    }
    if (completed) {
      setCompletedTrips(JSON.parse(completed));
    }
  }, []);

  const saveIncompleteTrip = (tripData: Partial<Trip>) => {
    const trip: Trip = {
      id: incompleteTrip?.id || Date.now().toString(),
      userId: tripData.userId || '',
      origin: tripData.origin || '',
      destination: tripData.destination || '',
      selectedRoute: tripData.selectedRoute,
      teamSize: tripData.teamSize || 1,
      teamName: tripData.teamName,
      tripTagline: tripData.tripTagline,
      coTravellers: tripData.coTravellers || [],
      images: tripData.images || [],
      status: 'incomplete',
      createdAt: incompleteTrip?.createdAt || new Date().toISOString(),
      ...tripData,
    };
    
    setIncompleteTrip(trip);
    localStorage.setItem('travel_app_incomplete_trip', JSON.stringify(trip));
  };

  const completeTrip = (trip: Trip) => {
    const completedTrip = {
      ...trip,
      status: 'completed' as const,
      completedAt: new Date().toISOString(),
    };
    
    const updatedTrips = [...completedTrips, completedTrip];
    setCompletedTrips(updatedTrips);
    localStorage.setItem('travel_app_completed_trips', JSON.stringify(updatedTrips));
    
    // Remove incomplete trip
    setIncompleteTrip(null);
    localStorage.removeItem('travel_app_incomplete_trip');
  };

  const discardIncompleteTrip = () => {
    setIncompleteTrip(null);
    localStorage.removeItem('travel_app_incomplete_trip');
  };

  const addReview = (reviewData: Omit<TripReview, 'id' | 'createdAt'>) => {
    const review: TripReview = {
      ...reviewData,
      id: Date.now().toString(),
      createdAt: new Date().toISOString(),
    };

    // Add review to the trip
    const updatedTrips = completedTrips.map(trip => {
      if (trip.id === review.tripId) {
        return {
          ...trip,
          reviews: [...(trip.reviews || []), review],
        };
      }
      return trip;
    });

    setCompletedTrips(updatedTrips);
    localStorage.setItem('travel_app_completed_trips', JSON.stringify(updatedTrips));

    // Award points to user (implement in AuthContext)
    const users = JSON.parse(localStorage.getItem('travel_app_users') || '[]');
    const userIndex = users.findIndex((u: any) => u.id === review.userId);
    if (userIndex !== -1) {
      users[userIndex].points = (users[userIndex].points || 0) + 10;
      localStorage.setItem('travel_app_users', JSON.stringify(users));
    }
  };

  const getReviewsForRoute = (origin: string, destination: string): TripReview[] => {
    const allReviews: TripReview[] = [];
    completedTrips.forEach(trip => {
      if (trip.origin === origin && trip.destination === destination && trip.reviews) {
        allReviews.push(...trip.reviews);
      }
    });
    return allReviews;
  };

  const generateRouteOptions = (origin: string, destination: string): TripRoute[] => {
    // Generate realistic base distance (10-500 km)
    const baseDistance = Math.floor(Math.random() * 490) + 10;
    
    return TRANSPORT_MODES.map((transport, index) => {
      // Add variance to distance for each mode
      const distanceVariance = (Math.random() - 0.5) * 0.2; // ±10%
      const distance = Math.round(baseDistance * (1 + distanceVariance));
      
      // Calculate duration based on speed
      const duration = Math.round((distance / transport.speed) * 60); // in minutes
      
      // Calculate cost with some variance
      const costVariance = (Math.random() - 0.5) * 0.3; // ±15%
      const cost = Math.round(distance * transport.costPerKm * (1 + costVariance));
      
      // Generate random co-traveller names
      const shuffledNames = [...SAMPLE_NAMES].sort(() => Math.random() - 0.5);
      const numCoTravellers = Math.floor(Math.random() * 8) + 2; // 2-10 co-travellers
      const coTravellers = shuffledNames.slice(0, numCoTravellers);

      return {
        id: `route_${Date.now()}_${index}`,
        mode: transport.mode,
        distance,
        duration,
        cost,
        coTravellers,
      };
    });
  };

  return (
    <TripContext.Provider
      value={{
        incompleteTrip,
        completedTrips,
        saveIncompleteTrip,
        completeTrip,
        discardIncompleteTrip,
        addReview,
        getReviewsForRoute,
        generateRouteOptions,
      }}
    >
      {children}
    </TripContext.Provider>
  );
};